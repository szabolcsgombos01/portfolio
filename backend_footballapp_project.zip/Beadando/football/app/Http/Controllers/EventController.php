<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\Player;
class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
    $validatedData = $request->validate([
        'minute' => 'required|integer|min:1|max:90',
        'type' => 'required|in:goal,own_goal,yellow_card,red_card',
        'game_id' => 'required|integer',
        'player_id' => 'required|integer',
    ]);
    
    $esemeny = new Event;
    $esemeny->type = $validatedData['type'];
    $esemeny->minute = $validatedData['minute'];
    $esemeny->game_id = $validatedData['game_id'];
    $esemeny->player_id = $validatedData['player_id'];
    $esemeny->save();

    return redirect()->back()->with('success', 'Az új esemény sikeresen hozzáadva.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Event $event)
    {
        $event->delete();
        return redirect()->back()->with('success', 'Az esemény sikeresen törölve lett!');
    }
}
