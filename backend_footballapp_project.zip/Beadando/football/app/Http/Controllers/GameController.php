<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Game;
use App\Models\Team;
use App\Models\Player;
use App\Models\Event;
use Illuminate\Support\Facades\Session;
class GameController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('games.games', [
        'games' => Game::all(),
        'finishedgames' => Game::where('finished', true )->orWhere('start' , '>' , now())->paginate(5),
        'teams' => Team::all(),
        'events' => Event::all()
        
    ]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    $validatedData = $request->validate([
        'home_team' => 'required|different:away_team',
        'away_team' => 'required',
        'start' => 'required|after:now',
    ]);

    if ($request->input('home_team') == $request->input('away_team')) {
        return back()->withInput()->withErrors(['away_team' => 'A hazai és vendég csapat nem lehet azonos.']);
    }
    $game = new Game();
    $game->home_team_id = $request->input('home_team');
    $game->away_team_id = $request->input('away_team');
    $game->start = $request->input('start');

    $game->save();

    return redirect()->route('games.index')->with('success', 'Az új meccs sikeresen hozzáadva.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Game $game)
    {            
        $playersOfHomeTeam = Player::where('team_id', $game->home_team_id)->get();
        $playersOfAwayTeam = Player::where('team_id', $game->away_team_id)->get();
        return view('games.show', [
            'game' => $game,
            'players' => Player::all(),
            'events' => Event::where('game_id', $game->id)->orderBy('minute')->get(),
            'playersofgame' => $playersOfHomeTeam->merge($playersOfAwayTeam),
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Game $game)
    {
        return view('games.edit', [
        'game' => $game,
        'teams' => Team::all(),
    ]);
    }
    public function finish(Game $game)
    {
    $game->update(['finished' => true]);
    return redirect()->back()->with('success', 'A mérkőzés befejezve.');
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Game $game)
    {
        $request->validate([
        'home_team' => 'required|different:away_team',
        'away_team' => 'required',
        'start' => 'required|after:now',
    ]);

    $game->home_team_id = $request->input('home_team');
    $game->away_team_id = $request->input('away_team');
    $game->start = $request->input('start');
    $game->save();

    return redirect()->route('games.index')->with('success', 'A mérkőzés sikeresen frissítve lett.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Game $game)
    {
        $events = Event::where('game_id', $game->id)->get();
        if ($events->isEmpty()) {
            Session::flash('post_deleted', $game['id']);
            $game->delete();
            return redirect()->back()->with('success', 'A mérkőzés törölve.');
        } else {
            return redirect()->back()->with('error', 'Nem törölhető a mérkőzés, mert hozzá van rendelve esemény.');
        }
    }
    
}
