<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\Player;
use App\Models\Game;
use App\Models\Team;
use Illuminate\Support\Facades\Session;


class PlayerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'number' => 'required|integer|min:1',
        'birthdate' => 'required|date',
        'team_id' => 'required|exists:teams,id'
    ]);

    $player = new Player;
    $player->name = $validatedData['name'];
    $player->team_id = $validatedData['team_id'];
    $player->number = $validatedData['number'];
    $player->birthdate = $validatedData['birthdate'];
    $player->save();

    return redirect()->route('teams.show', $request->team_id);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Player $player)
    {
            Session::flash('post_deleted', $player['id']);
            $player->delete();
            return redirect()->back()->with('success', 'A mérkőzés törölve.');
    }
}
