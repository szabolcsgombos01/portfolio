<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Game;
use App\Models\Team;
use App\Models\Player;
use App\Models\Event;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('teams.teams', [
        'games' => Game::all(),
        'teams' => Team::orderBy('name')->get(),
        'events' => Event::all(),
        
    ]);     
    }


    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    $validated = $request->validate([
        'name' => 'required|unique:teams',
        'shortname' => 'required|unique:teams|max:4',
        'image' => 'nullable|file|mimes:jpeg,png,jpg,|max:4096',
    ]);



    $logo_image_path='';
    if ($request->hasFile('image')) {
        $file = $request->file('image');
        $logo_image_path = '/storgae/.logo_image_'.Str::random(10).'.'.$file->getClientOriginalExtension();
        Storage::disk('public')->put($logo_image_path, $file->get());
    }
    $team = Team::factory()->create([
        'name' => $validated['name'],
        'shortname' => $validated['shortname'],
        'image' => $logo_image_path,

    ]);
    // $team = new Team;
    // $team->name = $request->name;
    // $team->shortname = $request->shortname;


    // $team->save();
    Session::flash('team_created', $validated['name']);
    return redirect()->route('teams.index');
    } 

    /**
     * Display the specified resource.
     */
    public function show(Team $team)
    {
        return view('teams.show', [
        'team' => $team,
        'games' => Game::all(),
        'teams' => Team::orderBy('name')->get(),
        'events' => Event::all(),
        'homeGames' => Game::where('home_team_id', $team->id)->orderBy('start')->get(),
        'awayGames' => Game::where('away_team_id', $team->id)->orderBy('start')->get(),
        
    ]);     
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Team $team)
    {
        return view('teams.edit', [
        'team' => $team,
        'teams' => Team::all(),
    ]);
    }

    /**
     * Update the specified resource in storage.
     */
 public function update(Request $request, Team $team)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'shortname' => [
            'required',
            Rule::unique('teams')->ignore($team->id),
            'max:4'
        ],
            'image' => 'nullable|file|mimes:jpeg,png,jpg,|max:4096',
        ]);

        $team->name = $validatedData['name'];
        $team->shortname = $validatedData['shortname'];

        $logo_image_path='';
        if ($request->hasFile('image')) {
        $file = $request->file('image');
        $logo_image_path = '/storgae/.logo_image_'.Str::random(10).'.'.$file->getClientOriginalExtension();
        Storage::disk('public')->put($logo_image_path, $file->get());
        }
        $team->image = $logo_image_path;
        $team->save();

        return redirect()->route('teams.index', $team)->with('success', 'Csapat frissítve!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
