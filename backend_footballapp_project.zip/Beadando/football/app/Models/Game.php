<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Event;

class Game extends Model
{
    protected $fillable = [ 'home_team_id', 'away_team_id', 'finished'];
    use HasFactory;
    public function events()
    {
        return $this->hasMany(Event::class);
    }
    public function homeTeam()
    {
        return $this->belongsTo(Team::class, 'home_team_id');
    }

    public function awayTeam()
    {
        return $this->belongsTo(Team::class, 'away_team_id');
    }
    public function getCurrentScore()
    {
        $homeTeamGoals = Event::where('game_id', $this->id)
            ->where('type', 'goal')
            ->whereHas('player', function ($query) {
                $query->where('team_id', $this->homeTeam->id);
            })
            ->count();
            
        $homeTeamOwnGoals = Event::where('game_id', $this->id)
            ->where('type', 'own_goal')
            ->whereHas('player', function ($query) {
                $query->where('team_id', $this->awayTeam->id);
            })
            ->count();

        $awayTeamGoals = Event::where('game_id', $this->id)
            ->where('type', 'goal')
            ->whereHas('player', function ($query) {
                $query->where('team_id', $this->awayTeam->id);
            })
            ->count();

        $awayTeamOwnGoals = Event::where('game_id', $this->id)
            ->where('type', 'own_goal')
            ->whereHas('player', function ($query) {
                $query->where('team_id', $this->homeTeam->id);
            })
            ->count();

        $homeTeamScore = $homeTeamGoals + $awayTeamOwnGoals;
        $awayTeamScore = $awayTeamGoals + $homeTeamOwnGoals;

        return [
            'home_team_score' => $homeTeamScore,
            'away_team_score' => $awayTeamScore,
        ];
    }
    public function finish(Game $game)
    {
    $game->finished = true;
    $game->save();

    return redirect()->back();
    }



}
