<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Player extends Model
{
    public function team() {
        return  $this -> belongsTo(Team::class , 'team_id' );
    }
    public function events()
    {
        return $this->hasMany(Event::class);
    }
    public function getGoalsAttribute()
    {
    return Event::where('type', 'goal')->where('player_id', $this->id)->count();
    }

    public function getOwnGoalsAttribute()
    {
        return Event::where('type', 'own_goal')->where('player_id', $this->id)->count();
    }

    public function getYellowCardsAttribute()
    {
        return Event::where('type', 'yellow_card')->where('player_id', $this->id)->count();
    }

    public function getRedCardsAttribute()
    {
        return Event::where('type', 'red_card')->where('player_id', $this->id)->count();
    }

    use HasFactory;
}
