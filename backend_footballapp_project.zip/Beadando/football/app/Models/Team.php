<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    public function players() {
        return $this-> hasMany(Player::class, 'team_id');
    }
    public function users() {
        return $this-> belongsToMany(User::class)->withTimestamps();
    }
    public function homeGames()
    {
        return $this->hasMany(Game::class, 'home_team_id');
    }

    public function awayGames()
    {
        return $this->hasMany(Game::class, 'away_team_id');
    }

    public function points()
    {
    $points = 0;
    $games = $this->homeGames->merge($this->awayGames);
    foreach ($games as $game) {
        $score = $game->getCurrentScore();
        if ($game->finished) {
            if ($score['home_team_score'] > $score['away_team_score']) {
                if ($game->home_team_id === $this->id) {
                    $points += 3;
                }
            } elseif ($score['away_team_score'] > $score['home_team_score']) {
                if ($game->away_team_id === $this->id) {
                    $points += 3;
                }
            } else {
                $points += 1;
            }
        }
    }
    return $points;
    }


    use HasFactory;
}
