<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Team>
 */
class TeamFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $name =fake()->unique()->city();
        $shortname = strtoupper(substr(str_shuffle($name),0,4));
        $shortname = fake() -> unique() -> regexify('[A-Z]{4}');

        return [
        'name' => $name . fake()->randomElement(['FC' , 'United' , 'City' , 'Athletic']),
        'shortname' => $shortname,
        'image' => fake()->optional()->imageUrl(),
        ];

    }


}
