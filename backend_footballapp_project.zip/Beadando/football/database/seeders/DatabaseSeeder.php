<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Game;
use App\Models\Player;
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        \App\Models\User::factory()->create([
            'name' => 'ADMIN',
            'email' => 'admin@szerveroldali.hu',
            'password' => bcrypt('adminpwd'),
            'is_admin' => true,
        ]);
    $teams = \App\Models\Team::factory(10)->create();

    
    // Létrehozunk három kategóriájú meccset: már lejátszott, jelenleg zajló és még nem kezdődött.
    for ($i=0; $i < 4 ; $i++) { 
            $playedGame = Game::factory()->create([
        'home_team_id' => $teams->random()->id,
        'away_team_id' => $teams->random()->id,
        'start' => now()->subHours(3),
        'finished' => true,
    ]);
    }

    for ($i=0; $i < 4 ; $i++) {
    $inProgressGame = Game::factory()->create([
        'home_team_id' => $teams->random()->id,
        'away_team_id' => $teams->random()->id,
        'start' => now()->subHours(1),
        'finished' => false,
    ]);
    }
    for ($i=0; $i < 4 ; $i++) {
    $upcomingGame = Game::factory()->create([
        'home_team_id' => $teams->random()->id,
        'away_team_id' => $teams->random()->id,
        'start' => now()->addHours(2),
        'finished' => false,
    ]);
    }
    $teams->each(function ($team) {
            $numPlayers = rand(4, 6);
            for ($i=0; $i < $numPlayers; $i++) { 
                Player::factory()->create([
                    'team_id' => $team->id,
                ]);
            }
        });

    // $players = \App\Models\Player::factory(10)->create();
    
    // foreach ($teams as $team) {
    //     foreach ($players as $player) {
    //     $player->team()->associate($teams->random())->save();
    //     $events = \App\Models\Event::factory(rand(1, 5))->create([
    //         'player_id' => $player->id,
    //         'game_id' => $inProgressGame->id
    //     ]);

    // }
    // }


            // Users
    // $usersData = [
    //     ['email' => 'user1@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user2@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user3@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user4@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user5@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user6@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user7@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user8@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user9@szerveroldali.hu', 'password' => bcrypt('password')],
    //     ['email' => 'user10@szerveroldali.hu', 'password' => bcrypt('password')],
    // ];

    // foreach ($usersData as $userData) {
    //     \App\Models\User::factory()->create([
    //         'name' => 'User',
    //         'email' => $userData['email'],
    //         'password' => $userData['password'],
    //     ]);
    // }
    for ($i=0; $i < 10; $i++) { 
            \App\Models\User::factory()->create([
            'email' => 'user' . $i. '@szerveroldali.hu',
        ]);
    }

    // Assign teams to users
    $users = \App\Models\User::all();

    foreach ($users as $user) {
        $user->team()->sync($teams->random(rand(1, 3)));
    }
    for( $i = 0 ; $i < 50 ; $i++ ) {
        $this->createEventsForGame();
    }
    
}

// private function createEventsForGame($game, $players, $finished)
// {
//     $numEvents = $finished ? 10 : rand(1, 5);
//     $numPlayers = $players->count();
//     $game1 = Game::random();
//     for ($i = 0; $i < $numEvents; $i++) {
//         $player = $players->random();
//         $event = \App\Models\Event::factory()->create([
//             'game_id' => $game->id,
//             'player_id' => rand(1 , $numPlayers),
//             'minute' => $finished ? rand(1, 90) : rand(1, 60),
//         ]);

//         if ($event->is_goal) {
//             $event->team_id = $event->player->team_id == $game->home_team_id ? $game->home_team_id : $game->away_team_id;
//             $event->save();
//         }
//     }
// }

private function createEventsForGame(){
    $game = Game::where('start', '<=', now()->subHour(1))->inRandomOrder()->get()->random();
    $players = ($game->homeTeam->players)->concat($game->awayTeam->players);
    $event = \App\Models\Event::factory()->create([
        'game_id' => $game->id,
        'player_id' => $players->random(),
    ]);
}
}
