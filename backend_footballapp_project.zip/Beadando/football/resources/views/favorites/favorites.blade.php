@if (Auth::check() && auth()->user())
    @extends ('layouts.app')
    @section('content')
        <h1>Kedvencek</h1>
        <div>
        </div>
    @endsection
@endif
