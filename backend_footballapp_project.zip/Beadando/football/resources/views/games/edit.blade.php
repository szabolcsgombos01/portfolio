@extends('layouts.app')

@section('content')
    <h1>Űrlap</h1>
    <form method="POST" action="{{ route('games.update', $game) }}" enctype="multipart/form-data">
        @method('PUT')
        @csrf
        <div>
            <label for="home_team">Hazai csapat:</label>
            <select name="home_team" id="home_team">
                <option value="">Válassz egy hazai csapatot</option>
                @foreach ($teams as $team)
                    <option value="{{ $team->id }}" @if ($team->id == $game->home_team_id) selected @endif>{{ $team->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="away_team">Vendég csapat:</label>
            <select name="away_team" id="away_team">
                <option value="">Válassz egy vendég csapatot</option>
                @foreach ($teams as $team)
                    <option value="{{ $team->id }}" @if ($team->id == $game->away_team_id) selected @endif>
                        {{ $team->name }} </option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="start">Kezdés időpontja:</label>
            <input type="datetime-local" id="start" name="start"
                value="{{ \Carbon\Carbon::parse($game->start)->format('Y-m-d\TH:i') }}">

            @error('start')
            </div class="invalid feedback">
            {{ $message }}
            </div>
        @enderror
        </div>
        <button type="submit">Mentés</button>
    </form>
@endsection
