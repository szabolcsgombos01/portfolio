@extends('layouts.app')

@section('content')
    <h1>Összes meccs</h1>
    <div class="container">

        <!-- Folyamatban lévő meccsek -->
        <h2>Folyamatban lévő meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>info</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Állás</th>
                    <th>Állapot</th>
                    @if (Auth::check() && auth()->user()->is_admin)
                        <th>Műveletek</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @foreach ($games as $game)
                    @if (!$game->finished && $game->start < now())
                        <tr>
                            <td>
                                <a href="{{ route('games.show', $game->id) }}">
                                    View game info
                                </a>
                            </td>
                            <td>
                                @if (App\Models\Team::find($game->home_team_id)->image)
                                    @if (strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0)
                                        <img src="{{ App\Models\Team::find($game->home_team_id)->image }}"
                                            alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @else
                                        <img src="{{ asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                            alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @endif
                                @else
                                    <img src="{{ asset('placeholder.png') }}"
                                        alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo" height="50">
                                @endif
                                {{ App\Models\Team::find($game->home_team_id)->name }}
                                vs
                                @if (App\Models\Team::find($game->away_team_id)->image)
                                    @if (strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0)
                                        <img src="{{ App\Models\Team::find($game->away_team_id)->image }}"
                                            alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @else
                                        <img src="{{ asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                            alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @endif
                                @else
                                    <img src="{{ asset('placeholder.png') }}"
                                        alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo" height="50">
                                @endif
                                {{ App\Models\Team::find($game->away_team_id)->name }}
                            </td>
                            <td>
                                {{ $game->start }}
                            </td>
                            <td>
                                {{ $game->getCurrentScore()['home_team_score'] }}
                                :
                                {{ $game->getCurrentScore()['away_team_score'] }}
                            </td>
                            <td>
                                Folyamatban
                            </td>
                            @if (Auth::check() && auth()->user()->is_admin)
                                <td>
                                    <a href="{{ route('games.edit', $game) }}">Szerkesztés</a>
                                    @if ($events->where('game_id', $game->id)->isEmpty())
                                        <form id="delete-game-form" action="{{ route('games.destroy', $game->id) }}"
                                            method="POST">
                                            @method('DELETE')
                                            @csrf
                                            <button type="submit">Delete</button>
                                        </form>
                                    @endif
                                </td>
                            @endif
                        </tr>
                    @endif
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="container">
        <!-- Befejezett és jövőbeli meccsek -->
        <h2>Befejezett és jövőbeli meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Info</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Eredmény</th>
                    <th>Állapot</th>
                    @if (Auth::check() && auth()->user()->is_admin)
                        <th>Műveletek</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @foreach ($finishedgames as $game)
                    @if ($game->finished || $game->start >= now())
                        <tr>
                            <td>
                                <a href={{ route('games.show', $game) }}>
                                    View game info
                                </a>
                            </td>

                            <td>
                                @if (App\Models\Team::find($game->home_team_id)->image)
                                    @if (strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0)
                                        <img src="{{ App\Models\Team::find($game->home_team_id)->image }}"
                                            alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @else
                                        <img src="{{ asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                            alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @endif
                                @else
                                    <img src="{{ asset('placeholder.png') }}"
                                        alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo" height="50">
                                @endif
                                {{ App\Models\Team::find($game->home_team_id)->name }}

                                vs
                                @if (App\Models\Team::find($game->away_team_id)->image)
                                    @if (strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0)
                                        <img src="{{ App\Models\Team::find($game->away_team_id)->image }}"
                                            alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @else
                                        <img src="{{ asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                            alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                            style="max-width: 40px; max-height: auto;">
                                    @endif
                                @else
                                    <img src="{{ asset('placeholder.png') }}"
                                        alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo" height="50">
                                @endif
                                {{ App\Models\Team::find($game->away_team_id)->name }}

                            </td>
                            <td>{{ $game->start }}</td>
                            <td>
                                @if (!$game->finished && $game->start < now())
                                    {{ $game->getCurrentScore()['home_team_score'] }}
                                    :
                                    {{ $game->getCurrentScore()['away_team_score'] }}
                                @else
                                    {{ $game->getCurrentScore()['home_team_score'] }}
                                    :
                                    {{ $game->getCurrentScore()['away_team_score'] }}
                                @endif
                            </td>
                            <td>
                                {{ $game->finished ? 'Befejezett' : 'Jövőbeli' }}
                            </td>
                            @if (Auth::check() && auth()->user()->is_admin)
                                <td>
                                    <a href="{{ route('games.edit', $game) }}">Szerkesztés</a>
                                    @if ($events->where('game_id', $game->id)->isEmpty())
                                        <form id="delete-game-form" action="{{ route('games.destroy', $game->id) }}"
                                            method="POST">
                                            @method('DELETE')
                                            @csrf
                                            <button type="submit">Delete</button>
                                        </form>
                                    @endif
                                </td>
                            @endif
                        </tr>
                    @endif
                @endforeach
            </tbody>
        </table>
    </div class="d-flex justify-content-center">
    {{ $finishedgames->links() }}
    <div>

    </div>
    @if (Auth::check() && auth()->user()->is_admin)
        <h1>Űrlap</h1>
        <div>
            <form method="POST" action="{{ route('games.store') }}">
                @csrf
                <div>
                    <label for="home_team">Hazai csapat:</label>
                    <select name="home_team" id="home_team" required>
                        <option value="">Válassz egy hazai csapatot</option>
                        @foreach ($teams as $team)
                            <option value="{{ $team->id }}">{{ $team->name }} </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label for="away_team">Vendég csapat:</label>
                    <select name="away_team" id="away_team" required>
                        <option value="">Válassz egy vendég csapatot</option>
                        @foreach ($teams as $team)
                            <option value="{{ $team->id }}">{{ $team->name }} </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label for="start">Kezdés időpontja:</label>
                    <input type="datetime-local" id="start" name="start" required>
                </div>
                <button type="submit">Mentés</button>
            </form>

        </div>
    @endif
@endsection
