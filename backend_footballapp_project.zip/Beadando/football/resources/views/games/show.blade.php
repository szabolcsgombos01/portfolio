@extends ('layouts.app')
@section('content')
    <h1>Aktuális meccs</h1>
    @if (Auth::check() && auth()->user()->is_admin && !$game->finished)
        <form method="POST" action="{{ route('games.finish', $game->id) }}">
            @csrf
            <button type="submit" class="btn btn-primary">Mérkőzés befejezése</button>
        </form>
    @endif
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Csapatok</th>
                <th>Kezdődik</th>
                <th>Eredmény</th>
                <th>Állapot</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    @if (App\Models\Team::find($game->home_team_id)->image)
                        @if (strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0)
                            <img src="{{ App\Models\Team::find($game->home_team_id)->image }}"
                                alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                style="max-width: 40px; max-height: auto;">
                        @else
                            <img src="{{ asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo"
                                style="max-width: 40px; max-height: auto;">
                        @endif
                    @else
                        <img src="{{ asset('placeholder.png') }}"
                            alt="{{ App\Models\Team::find($game->home_team_id)->name }} logo" height="50">
                    @endif
                    {{ App\Models\Team::find($game->home_team_id)->name }}

                    vs
                    @if (App\Models\Team::find($game->away_team_id)->image)
                        @if (strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0)
                            <img src="{{ App\Models\Team::find($game->away_team_id)->image }}"
                                alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                style="max-width: 40px; max-height: auto;">
                        @else
                            <img src="{{ asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png') }}"
                                alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo"
                                style="max-width: 40px; max-height: auto;">
                        @endif
                    @else
                        <img src="{{ asset('placeholder.png') }}"
                            alt="{{ App\Models\Team::find($game->away_team_id)->name }} logo" height="50">
                    @endif
                    {{ App\Models\Team::find($game->away_team_id)->name }}

                </td>
                <td>{{ $game->start }}</td>
                <td>
                    @if (!$game->finished && $game->start < now())
                        {{ $game->getCurrentScore()['home_team_score'] }}
                        :
                        {{ $game->getCurrentScore()['away_team_score'] }}
                    @else
                        {{ $game->getCurrentScore()['home_team_score'] }}
                        :
                        {{ $game->getCurrentScore()['away_team_score'] }}
                    @endif
                </td>
                <td>
                    {{ $game->finished ? 'Befejezett' : 'Jövőbeli' }}
                </td>
            </tr>
        </tbody>
    </table>

    <div>
        <h3>Események</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Esemeny</th>
                    <th>Perc</th>
                    <th>Csapat</th>
                    <th>Player </th>
                    @if (Auth::check() && auth()->user()->is_admin && !$game->finished)
                        <th>Törlés</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @foreach ($events as $event)
                    <tr>
                        <td>
                            {{ $event->type }}
                        </td>

                        <td>
                            {{ $event->minute }}
                        </td>
                        <td>
                            @php
                                $player = App\Models\Player::where('id', $event->player_id)->first();
                                if ($player) {
                                    $team = App\Models\Team::find($player->team_id);
                                    if ($team) {
                                        echo $team->name;
                                    } else {
                                        echo 'N/A';
                                    }
                                } else {
                                    echo 'N/A';
                                }
                            @endphp
                        </td>
                        <td>
                            @php
                                $player = App\Models\Player::where('id', $event->player_id)->first();
                                if ($player) {
                                    $playerName = $player->name;
                                    echo $playerName;
                                } else {
                                    echo 'N/A';
                                }
                            @endphp
                        </td>
                        @if (Auth::check() && auth()->user()->is_admin && !$game->finished)
                            <td>
                                <form method="POST" action="{{ route('events.destroy', $event->id) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Törlés</button>
                                </form>
                            </td>
                        @endif
                @endforeach
                </tr>
            </tbody>
        </table>
    </div>

    @if (Auth::check() && auth()->user()->is_admin && !$game->finished)
        <h1>Űrlap</h1>
        <form method="POST" action="{{ route('events.store') }}">
            @csrf
            <div class="form-group">
                <label for="minute">Perc:</label>
                <input type="number" name="minute" id="minute" class="form-control" min="1" max="90"
                    required>
            </div>
            <div class="form-group">
                <label for="type">Típus:</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="goal">Gól</option>
                    <option value="own_goal">Öngól</option>
                    <option value="yellow_card">Sárga lap</option>
                    <option value="red_card">Piros lap</option>
                </select>
            </div>
            <div class="form-group">
                <label for="player">Játékos:</label>
                <select name="player_id" id="player" class="form-control" required>
                    <option value="">Válassz egy játékost</option>
                    @foreach ($playersofgame as $player)
                        <option value="{{ $player->id }}">{{ $player->team->name }} - {{ $player->jersey_number }} -
                            {{ $player->name }}</option>
                    @endforeach
                </select>
            </div>
            <input type="hidden" name="game_id" value="{{ $game->id }}">
            <button type="submit" class="btn btn-primary">Mentés</button>
        </form>
    @endif

@endsection
