@extends ('layouts.app')
@section('content')
    <h1>Tabella</h1>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>Csapatok</th>
                    <th>Pontok</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($teams as $team)
                    <tr>
                        <td>{{ $team->name }}</td>
                        <td>{{ $team->points() }}</td>
                    </tr>
                @endforeach
            </tbody>

        </table>
    </div>
@endsection
