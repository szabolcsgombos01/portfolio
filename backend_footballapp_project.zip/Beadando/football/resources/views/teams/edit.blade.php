@extends('layouts.app')

@section('content')
    <form method="POST" action="{{ route('team.update', $team) }}" enctype="multipart/form-data">
        <h1>Csapat szerkesztő Űrlap</h1>
        @method('PUT')
        @csrf
        <div>
            <label for="name">Csapat neve:</label>
            <input value="{{ $team->name }}" name="name" id="name" required>
        </div>
        <div>
            <label for="shortname">Rövid neve:</label>
            <input value="{{ $team->shortname }}" name="shortname" id="shortname" required>
        </div>
        <div>
            <label for="image">Csapat logója:</label>
            <input value="{{ $team->image }}" type="file" name="image" id="image">
        </div>
        <button type="submit">Mentés</button>
    </form>
@endsection
