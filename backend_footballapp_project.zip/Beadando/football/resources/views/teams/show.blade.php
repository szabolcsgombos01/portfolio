@extends ('layouts.app')

@section('content')
    <div>
        <div class="team">
            <h1>Csapat leírása</h1>
            <h2> Csapat neve:</h2>
            <h3>{{ $team->name }} </h3>
            <h2>Csapat rövíd neve:</h2>
            <h3>{{ $team->shortname }}</h3>
            <div>
                <h2>Logo:</h2>
                @if (strpos($team->image, 'https://') === 0)
                    <img src="{{ $team->image }}" alt="{{ $team->name }} logo" style="max-width: 40px; max-height: auto;">
                @else
                    <img src="{{ asset($team->image ? 'storage/' . $team->image : 'placeholder.png') }}"
                        style="max-width: 40px; max-height: auto;">
                @endif
            </div>


        </div>
        <br>
        <br>
        <br>
        <div>
            <h3>Mérkőzések:</h3>
            @if ($team->homeGames()->get()->merge($team->awayGames()->get())->count() == 0)
                <h3>Nincs még mérkőzés</h3>
            @else
                <table>
                    <thead>
                        <tr>
                            <th>
                                <h3>Dátum</h3>
                            </th>
                            <th>
                                <h3>Hazaik</h3>
                            </th>
                            <th>
                                <h3>Vendégek</h3>
                            </th>
                            <th>
                                <h3>Eredmény</h3>
                            </th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($team->homeGames()->get()->merge($team->awayGames()->get()) as $game)
                            <tr>
                                <td>{{ $game->start }}</td>
                                <td>{{ $game->homeTeam->name }} - </td>
                                <td>{{ $game->awayTeam->name }}</td>
                                <td>
                                    @if (!$game->finished)
                                        Folyamatban
                                    @elseif ($game->finished)
                                        {{ $game->getCurrentScore()['home_team_score'] }}
                                        :
                                        {{ $game->getCurrentScore()['away_team_score'] }}
                                    @else
                                        Nem játszott
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endif
        </div>
        <br>
        <br>
        <br>
        <div>
            <h3>Játékosok:</h3>
            <table>
                <thead>
                    <tr>
                        <th>
                            <h3> Név </h3>
                        </th>
                        <th>
                            <h3>Születési dátum</h3>
                        </th>
                        <th>
                            <h3>Gólok száma</h3>
                        </th>
                        <th>
                            <h3>Öngólok száma</h3>
                        </th>
                        <th>
                            <h3>Sárga lapok száma</h3>
                        </th>
                        <th>
                            <h3>Piros lapok száma</h3>
                        </th>
                        @if (Auth::check() && auth()->user()->is_admin)
                            <th>
                                <h3>Törlés</h3>
                            </th>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach ($team->players as $player)
                        <tr>
                            <td>{{ $player->name }}</td>
                            <td>{{ $player->birthdate }}</td>
                            <td>{{ $player->getGoalsAttribute() }}</td>
                            <td>{{ $player->getOwnGoalsAttribute() }}</td>
                            <td>{{ $player->getYellowCardsAttribute() }}</td>
                            <td>{{ $player->getRedCardsAttribute() }}</td>
                            @if (Auth::check() && auth()->user()->is_admin)
                                <td>
                                    @if ($events->where('player_id', $player->id)->isEmpty())
                                        <form id="delete-player-form" action="{{ route('players.destroy', $player) }}"
                                            method="POST">
                                            @method('DELETE')
                                            @csrf
                                            <button type="submit">Delete</button>
                                        </form>
                                    @endif
                                </td>
                            @endif
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <br>
        <br>
        <br>
        @if (Auth::check() && auth()->user()->is_admin)
            <h1>Játékos felvevő űrlap</h1>
            <div>
                <form method="POST" action="{{ route('players.store') }}">
                    @csrf
                    <div>
                        <label for="name">Név:</label>
                        <input type="text" name="name" id="name" required>
                    </div>
                    <div>
                        <label for="number">Mezszám:</label>
                        <input type="number" name="number" id="number" required>
                    </div>
                    <div>
                        <label for="birthdate">Születési dátum:</label>
                        <input type="date" name="birthdate" id="birthdate" required>
                    </div>
                    <input type="hidden" name="team_id" value="{{ $team->id }}">
                    <button type="submit">Játékos hozzáadása</button>
                </form>
            </div>
        @endif
    </div>
@endsection
