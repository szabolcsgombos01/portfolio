@extends ('layouts.app')
@section('content')
    <h1>Csapatok</h1>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>Info</th>
                    <th>Logo</th>
                    <th>Name</th>
                    <th>Short Name</th>
                    @if (Auth::check() && auth()->user()->is_admin)
                        <th>Műveletek</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @foreach ($teams as $team)
                    <tr>
                        <td>
                            <a href="{{ route('teams.show', $team) }}">
                                View team info
                            </a>
                        </td>
                        <td>
                            @if ($team->image)
                                @if (strpos($team->image, 'https://') === 0)
                                    <img src="{{ $team->image }}" alt="{{ $team->name }} logo"
                                        style="max-width: 40px; max-height: auto;">
                                @else
                                    <img src="{{ asset($team->image ? 'storage/' . $team->image : 'placeholder.png') }}"
                                        style="max-width: 40px; max-height: auto;">
                                @endif
                            @else
                                <img src="{{ asset('placeholder.png') }}" alt="{{ $team->name }} logo" height="50">
                            @endif
                        </td>
                        <td>{{ $team->name }}</td>
                        <td>{{ $team->shortname }}</td>
                        @if (Auth::check() && auth()->user()->is_admin)
                            <td>
                                <a href="{{ route('teams.edit', $team) }}">Szerkesztés</a>
                            </td>
                        @endif
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @if (Auth::check() && auth()->user()->is_admin)
        <h1>Űrlap</h1>
        <div>
            <form method="POST" action="{{ route('teams.store') }}" enctype="multipart/form-data">
                @csrf
                <div>
                    <label for="name">Csapat neve:</label>
                    <input name="name" id="name" required>
                </div>
                <div>
                    <label for="shortname">Rövid neve:</label>
                    <input name="shortname" id="shortname" required>
                </div>
                <div>
                    <label for="image">Csapat logója:</label>
                    <input type="file" name="image" id="image">
                </div>
                <button type="submit">Mentés</button>
            </form>

        </div>
    @endif
@endsection
