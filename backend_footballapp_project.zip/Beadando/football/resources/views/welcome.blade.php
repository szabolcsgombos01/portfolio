@extends('layouts.app')

@section('content')
    <!DOCTYPE html>
    <html>

    <head>
        <title>Laravel alkalmazás</title>
    </head>

    <body>
        <h1>Üdvözöljük az alkalmazásunkban!</h1>
        <p>Ez egy labdarugó bajnokságot kezelő főoldal, amely tartalmazza a következő menüpontokat:</p>
        <ul>
            <li><a href="games">Mérkőzések</a></li>
            <li><a href="/teams">Csapatok</a></li>
            <li><a href="/table">Tabella</a></li>
            <li><a href="/favorites">Kedvenceim</a></li>
        </ul>
    </body>

    </html>
@endsection
