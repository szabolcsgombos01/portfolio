<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GameController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\PlayerController;
use App\Models\Game;
use App\Models\Team;
use App\Models\Player;
use App\Models\Event;
Route::get('/', function () {
    return view('welcome');
});
Route::get('/table', function () {
        return view('table.table', [
        'games' => Game::all(),
        'teams' => Team::all(),
        'events' => Event::all()
        
    ]);
});
Route::get('/favorites', function () {
        return view('favorites.favorites', [
        'games' => Game::all(),
        'teams' => Team::all(),
        'events' => Event::all()
        
    ]);
});

Route::resource('games' , GameController::class);
Route::resource('teams' , TeamController::class);
Route::resource('events' , EventController::class);
Route::resource('players' , PlayerController::class);
Auth::routes();
Route::post('/games/{game}/finish', [App\Http\Controllers\GameController::class, 'finish'])->name('games.finish');
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/games/{id}/edit', [App\Http\Controllers\GameController::class, 'edit'])->name('games.edit');
Route::put('/team/{team}', [TeamController::class, 'update'])->name('team.update');
