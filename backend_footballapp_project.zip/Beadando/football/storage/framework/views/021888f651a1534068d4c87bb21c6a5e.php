<?php $__env->startSection('content'); ?>
    <h1>Összes meccs</h1>
    <div class="container">

        <!-- Folyamatban lévő meccsek -->
        <h2>Folyamatban lévő meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>info</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Állás</th>
                    <th>Állapot</th>
                    <?php if(Auth::check() && auth()->user()->is_admin): ?>
                        <th>Műveletek</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$game->finished && $game->start < now()): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('games.show', $game->id)); ?>">
                                    View game info
                                </a>
                            </td>
                            <td>
                                <?php if(App\Models\Team::find($game->home_team_id)->image): ?>
                                    <?php if(strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0): ?>
                                        <img src="<?php echo e(App\Models\Team::find($game->home_team_id)->image); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->home_team_id)->name); ?>

                                vs
                                <?php if(App\Models\Team::find($game->away_team_id)->image): ?>
                                    <?php if(strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0): ?>
                                        <img src="<?php echo e(App\Models\Team::find($game->away_team_id)->image); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->away_team_id)->name); ?>

                            </td>
                            <td>
                                <?php echo e($game->start); ?>

                            </td>
                            <td>
                                <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                :
                                <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                            </td>
                            <td>
                                Folyamatban
                            </td>
                            <?php if(Auth::check() && auth()->user()->is_admin): ?>
                                <td>
                                    <a href="<?php echo e(route('games.edit', $game)); ?>">Szerkesztés</a>
                                    <?php if($events->where('game_id', $game->id)->isEmpty()): ?>
                                        <form id="delete-game-form" action="<?php echo e(route('games.destroy', $game->id)); ?>"
                                            method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="container">
        <!-- Befejezett és jövőbeli meccsek -->
        <h2>Befejezett és jövőbeli meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Info</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Eredmény</th>
                    <th>Állapot</th>
                    <?php if(Auth::check() && auth()->user()->is_admin): ?>
                        <th>Műveletek</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $finishedgames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($game->finished || $game->start >= now()): ?>
                        <tr>
                            <td>
                                <a href=<?php echo e(route('games.show', $game)); ?>>
                                    View game info
                                </a>
                            </td>

                            <td>
                                <?php if(App\Models\Team::find($game->home_team_id)->image): ?>
                                    <?php if(strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0): ?>
                                        <img src="<?php echo e(App\Models\Team::find($game->home_team_id)->image); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->home_team_id)->name); ?>


                                vs
                                <?php if(App\Models\Team::find($game->away_team_id)->image): ?>
                                    <?php if(strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0): ?>
                                        <img src="<?php echo e(App\Models\Team::find($game->away_team_id)->image); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                            alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                            style="max-width: 40px; max-height: auto;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->away_team_id)->name); ?>


                            </td>
                            <td><?php echo e($game->start); ?></td>
                            <td>
                                <?php if(!$game->finished && $game->start < now()): ?>
                                    <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                    :
                                    <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                                <?php else: ?>
                                    <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                    :
                                    <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($game->finished ? 'Befejezett' : 'Jövőbeli'); ?>

                            </td>
                            <?php if(Auth::check() && auth()->user()->is_admin): ?>
                                <td>
                                    <a href="<?php echo e(route('games.edit', $game)); ?>">Szerkesztés</a>
                                    <?php if($events->where('game_id', $game->id)->isEmpty()): ?>
                                        <form id="delete-game-form" action="<?php echo e(route('games.destroy', $game->id)); ?>"
                                            method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div class="d-flex justify-content-center">
    <?php echo e($finishedgames->links()); ?>

    <div>

    </div>
    <?php if(Auth::check() && auth()->user()->is_admin): ?>
        <div>
            <form method="POST" action="<?php echo e(route('games.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="home_team">Hazai csapat:</label>
                    <select name="home_team" id="home_team" required>
                        <option value="">Válassz egy hazai csapatot</option>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="away_team">Vendég csapat:</label>
                    <select name="away_team" id="away_team" required>
                        <option value="">Válassz egy vendég csapatot</option>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="start">Kezdés időpontja:</label>
                    <input type="datetime-local" id="start" name="start" required>
                </div>
                <button type="submit">Mentés</button>
            </form>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/games/games.blade.php ENDPATH**/ ?>