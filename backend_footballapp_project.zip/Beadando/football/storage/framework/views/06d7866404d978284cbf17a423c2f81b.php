<h1>Games</h1>
<?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($game->id); ?></h2>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/matches.blade.php ENDPATH**/ ?>