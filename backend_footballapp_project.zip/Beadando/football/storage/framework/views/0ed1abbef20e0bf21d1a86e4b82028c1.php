<?php $__env->startSection('content'); ?>
    <h1>Aktuális meccs</h1>
    <?php if(Auth::check() && auth()->user()->is_admin && !$game->finished): ?>
        <form method="POST" action="<?php echo e(route('games.finish', $game->id)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Mérkőzés befejezése</button>
        </form>
    <?php endif; ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Csapatok</th>
                <th>Kezdődik</th>
                <th>Eredmény</th>
                <th>Állapot</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php if(App\Models\Team::find($game->home_team_id)->image): ?>
                        <?php if(strpos(App\Models\Team::find($game->home_team_id)->image, 'https://') === 0): ?>
                            <img src="<?php echo e(App\Models\Team::find($game->home_team_id)->image); ?>"
                                alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                style="max-width: 40px; max-height: auto;">
                        <?php else: ?>
                            <img src="<?php echo e(asset(App\Models\Team::find($game->home_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                style="max-width: 40px; max-height: auto;">
                        <?php endif; ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('placeholder.png')); ?>"
                            alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo" height="50">
                    <?php endif; ?>
                    <?php echo e(App\Models\Team::find($game->home_team_id)->name); ?>


                    vs
                    <?php if(App\Models\Team::find($game->away_team_id)->image): ?>
                        <?php if(strpos(App\Models\Team::find($game->away_team_id)->image, 'https://') === 0): ?>
                            <img src="<?php echo e(App\Models\Team::find($game->away_team_id)->image); ?>"
                                alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                style="max-width: 40px; max-height: auto;">
                        <?php else: ?>
                            <img src="<?php echo e(asset(App\Models\Team::find($game->away_team_id)->image ? 'storage/' . App\Models\Team::find($game->home_team_id)->image : 'placeholder.png')); ?>"
                                alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                style="max-width: 40px; max-height: auto;">
                        <?php endif; ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('placeholder.png')); ?>"
                            alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo" height="50">
                    <?php endif; ?>
                    <?php echo e(App\Models\Team::find($game->away_team_id)->name); ?>


                </td>
                <td><?php echo e($game->start); ?></td>
                <td>
                    <?php if(!$game->finished && $game->start < now()): ?>
                        <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                        :
                        <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                    <?php else: ?>
                        <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                        :
                        <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($game->finished ? 'Befejezett' : 'Jövőbeli'); ?>

                </td>
            </tr>
        </tbody>
    </table>

    <div>
        <h3>Események</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Esemeny</th>
                    <th>Perc</th>
                    <th>Csapat</th>
                    <th>Player </th>
                    <?php if(Auth::check() && auth()->user()->is_admin && !$game->finished): ?>
                        <th>Törlés</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($event->type); ?>

                        </td>

                        <td>
                            <?php echo e($event->minute); ?>

                        </td>
                        <td>
                            <?php
                                $player = App\Models\Player::where('id', $event->player_id)->first();
                                if ($player) {
                                    $team = App\Models\Team::find($player->team_id);
                                    if ($team) {
                                        echo $team->name;
                                    } else {
                                        echo 'N/A';
                                    }
                                } else {
                                    echo 'N/A';
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $player = App\Models\Player::where('id', $event->player_id)->first();
                                if ($player) {
                                    $playerName = $player->name;
                                    echo $playerName;
                                } else {
                                    echo 'N/A';
                                }
                            ?>
                        </td>
                        <?php if(Auth::check() && auth()->user()->is_admin && !$game->finished): ?>
                            <td>
                                <form method="POST" action="<?php echo e(route('events.destroy', $event->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Törlés</button>
                                </form>
                            </td>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    </div>

    <?php if(Auth::check() && auth()->user()->is_admin && !$game->finished): ?>
        <form method="POST" action="<?php echo e(route('events.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="minute">Perc:</label>
                <input type="number" name="minute" id="minute" class="form-control" min="1" max="90"
                    required>
            </div>
            <div class="form-group">
                <label for="type">Típus:</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="goal">Gól</option>
                    <option value="own_goal">Öngól</option>
                    <option value="yellow_card">Sárga lap</option>
                    <option value="red_card">Piros lap</option>
                </select>
            </div>
            <div class="form-group">
                <label for="player">Játékos:</label>
                <select name="player_id" id="player" class="form-control" required>
                    <option value="">Válassz egy játékost</option>
                    <?php $__currentLoopData = $playersofgame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($player->id); ?>"><?php echo e($player->team->name); ?> - <?php echo e($player->jersey_number); ?> -
                            <?php echo e($player->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <input type="hidden" name="game_id" value="<?php echo e($game->id); ?>">
            <button type="submit" class="btn btn-primary">Mentés</button>
        </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/games/show.blade.php ENDPATH**/ ?>