<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Laravel alkalmazás</title>
    </head>

    <body>
        <h1>Üdvözöljük az alkalmazásunkban!</h1>
        <p>Ez egy labdarugó bajnokságot kezelő főoldal, amely tartalmazza a következő menüpontokat:</p>
        <ul>
            <li><a href="games">Mérkőzések</a></li>
            <li><a href="/teams">Csapatok</a></li>
            <li><a href="/table">Tabella</a></li>
            <li><a href="/favorites">Kedvenceim</a></li>
        </ul>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/welcome.blade.php ENDPATH**/ ?>