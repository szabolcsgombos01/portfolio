<?php $__env->startSection('content'); ?>
    <h1>Űrlap</h1>
    <form method="POST" action="<?php echo e(route('games.update', $game)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div>
            <label for="home_team">Hazai csapat:</label>
            <select name="home_team" id="home_team">
                <option value="">Válassz egy hazai csapatot</option>
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($team->id); ?>" <?php if($team->id == $game->home_team_id): ?> selected <?php endif; ?>><?php echo e($team->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="away_team">Vendég csapat:</label>
            <select name="away_team" id="away_team">
                <option value="">Válassz egy vendég csapatot</option>
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($team->id); ?>" <?php if($team->id == $game->away_team_id): ?> selected <?php endif; ?>>
                        <?php echo e($team->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="start">Kezdés időpontja:</label>
            <input type="datetime-local" id="start" name="start"
                value="<?php echo e(\Carbon\Carbon::parse($game->start)->format('Y-m-d\TH:i')); ?>">

            <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            </div class="invalid feedback">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit">Mentés</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Beadando/football/resources/views/games/edit.blade.php ENDPATH**/ ?>