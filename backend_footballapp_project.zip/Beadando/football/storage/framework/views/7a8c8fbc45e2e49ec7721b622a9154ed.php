<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('team.update', $team)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Csapat neve:</label>
            <input value="<?php echo e($team->name); ?>" name="name" id="name" required>
        </div>
        <div>
            <label for="shortname">Rövid neve:</label>
            <input value="<?php echo e($team->shortname); ?>" name="shortname" id="shortname" required>
        </div>
        <div>
            <label for="image">Csapat logója:</label>
            <input value="<?php echo e($team->image); ?>" type="file" name="image" id="image">
        </div>
        <button type="submit">Mentés</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/teams/edit.blade.php ENDPATH**/ ?>