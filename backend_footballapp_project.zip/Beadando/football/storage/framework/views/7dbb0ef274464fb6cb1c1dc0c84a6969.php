<?php if(Auth::check() && auth()->user()): ?>
    
    <?php $__env->startSection('content'); ?>
        <h1>Kedvencek</h1>
        <div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Beadando/football/resources/views/favorites/favorites.blade.php ENDPATH**/ ?>