<?php $__env->startSection('content'); ?>
    <h1>Csapatok</h1>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>Csapatok</th>
                    <th>Pontok</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($team->name); ?></td>
                        <td><?php echo e($team->points()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/table/table.blade.php ENDPATH**/ ?>