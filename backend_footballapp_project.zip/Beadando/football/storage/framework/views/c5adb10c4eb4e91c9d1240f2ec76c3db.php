<?php $__env->startSection('content'); ?>
    <h1>Csapatok</h1>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>Info</th>
                    <th>Logo</th>
                    <th>Name</th>
                    <th>Short Name</th>
                    <?php if(Auth::check() && auth()->user()->is_admin): ?>
                        <th>Műveletek</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('teams.show', $team)); ?>">
                                View team info
                            </a>
                        </td>
                        <td>
                            <?php if($team->image): ?>
                                <?php if(strpos($team->image, 'https://') === 0): ?>
                                    <img src="<?php echo e($team->image); ?>" alt="<?php echo e($team->name); ?> logo"
                                        style="max-width: 40px; max-height: auto;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset($team->image ? 'storage/' . $team->image : 'placeholder.png')); ?>"
                                        style="max-width: 40px; max-height: auto;">
                                <?php endif; ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('placeholder.png')); ?>" alt="<?php echo e($team->name); ?> logo" height="50">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($team->name); ?></td>
                        <td><?php echo e($team->shortname); ?></td>
                        <?php if(Auth::check() && auth()->user()->is_admin): ?>
                            <td>
                                <a href="<?php echo e(route('teams.edit', $team)); ?>">Szerkesztés</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if(Auth::check() && auth()->user()->is_admin): ?>
        <div>
            <form method="POST" action="<?php echo e(route('teams.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="name">Csapat neve:</label>
                    <input name="name" id="name" required>
                </div>
                <div>
                    <label for="shortname">Rövid neve:</label>
                    <input name="shortname" id="shortname" required>
                </div>
                <div>
                    <label for="image">Csapat logója:</label>
                    <input type="file" name="image" id="image">
                </div>
                <button type="submit">Mentés</button>
            </form>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/teams/teams.blade.php ENDPATH**/ ?>