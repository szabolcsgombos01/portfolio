<?php $__env->startSection('content'); ?>
    <div>
        <div class="team">
            <h1>Csapat leírása</h1>
            <h2> Csapat neve: <?php echo e($team->name); ?></h2>
            <p>Csapat rövíd neve: <?php echo e($team->shortname); ?></p>
            <div>
                <p>Logo:</p>
                <?php if(strpos($team->image, 'https://') === 0): ?>
                    <img src="<?php echo e($team->image); ?>" alt="<?php echo e($team->name); ?> logo" style="max-width: 40px; max-height: auto;">
                <?php else: ?>
                    <img src="<?php echo e(asset($team->image ? 'storage/' . $team->image : 'placeholder.png')); ?>"
                        style="max-width: 40px; max-height: auto;">
                <?php endif; ?>
            </div>


        </div>
        <div>
            <h3>Mérkőzések:</h3>
            <table>
                <thead>
                    <tr>
                        <th>Dátum</th>
                        <th>Hazaik</th>
                        <th>Vendégek</th>
                        <th>Eredmény</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $team->homeGames()->get()->merge($team->awayGames()->get()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($game->start); ?></td>
                            <td><?php echo e($game->homeTeam->name); ?> - </td>
                            <td><?php echo e($game->awayTeam->name); ?></td>
                            <td>
                                <?php if(!$game->finished): ?>
                                    Folyamatban
                                <?php elseif($game->finished): ?>
                                    <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                    :
                                    <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                                <?php else: ?>
                                    Nem játszott
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div>
            <h3>Játékosok:</h3>
            <table>
                <thead>
                    <tr>
                        <th>Név</th>
                        <th>Születési dátum</th>
                        <th>Gólok száma</th>
                        <th>Öngólok száma</th>
                        <th>Sárga lapok száma</th>
                        <th>Piros lapok száma</th>
                        <?php if(Auth::check() && auth()->user()->is_admin): ?>
                            <th>Törlés</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($player->name); ?></td>
                            <td><?php echo e($player->birthdate); ?></td>
                            <td><?php echo e($player->getGoalsAttribute()); ?></td>
                            <td><?php echo e($player->getOwnGoalsAttribute()); ?></td>
                            <td><?php echo e($player->getYellowCardsAttribute()); ?></td>
                            <td><?php echo e($player->getRedCardsAttribute()); ?></td>
                            <?php if(Auth::check() && auth()->user()->is_admin): ?>
                                <td>
                                    <?php if($events->where('player_id', $player->id)->isEmpty()): ?>
                                        <form id="delete-player-form" action="<?php echo e(route('players.destroy', $player)); ?>"
                                            method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php if(Auth::check() && auth()->user()->is_admin): ?>
            <div>
                <form method="POST" action="<?php echo e(route('players.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="name">Név:</label>
                        <input type="text" name="name" id="name" required>
                    </div>
                    <div>
                        <label for="number">Mezszám:</label>
                        <input type="number" name="number" id="number" required>
                    </div>
                    <div>
                        <label for="birthdate">Születési dátum:</label>
                        <input type="date" name="birthdate" id="birthdate" required>
                    </div>
                    <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>">
                    <button type="submit">Játékos hozzáadása</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/teams/show.blade.php ENDPATH**/ ?>