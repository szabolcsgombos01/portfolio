<?php $__env->startSection('content'); ?>
    <h1>Összes meccs</h1>
    <div class="container">

        <!-- Folyamatban lévő meccsek -->
        <h2>Folyamatban lévő meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Állás</th>
                    <th>Állapot</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$game->finished && $game->start < now()): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('games.show', $game->id)); ?>">
                                    <?php echo e($game->id); ?>

                                </a>
                            </td>
                            <td>
                                <?php if(App\Models\Team::find($game->home_team_id)->image): ?>
                                    <img src="<?php echo e(App\Models\Team::find($game->home_team_id)->image); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                        style="max-width: 40px; max-height: auto;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->home_team_id)->name); ?>

                                vs
                                <?php if(App\Models\Team::find($game->away_team_id)->image): ?>
                                    <img src="<?php echo e(App\Models\Team::find($game->away_team_id)->image); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                        style="max-width: 40px; max-height: auto;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->away_team_id)->name); ?>

                            </td>
                            <td>
                                <?php echo e($game->start); ?>

                            </td>
                            <td>
                                <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                :
                                <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                            </td>
                            <td>
                                Folyamatban
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="container">
        <!-- Befejezett és jövőbeli meccsek -->
        <h2>Befejezett és jövőbeli meccsek</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Csapatok</th>
                    <th>Kezdődik</th>
                    <th>Eredmény</th>
                    <th>Állapot</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($game->finished || $game->start >= now()): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('games.show', $game)); ?>">
                                    <?php echo e($game->id); ?>

                                </a>
                            </td>

                            <td>
                                <?php if(App\Models\Team::find($game->home_team_id)->image): ?>
                                    <img src="<?php echo e(App\Models\Team::find($game->home_team_id)->image); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo"
                                        style="max-width: 40px; max-height: auto;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->home_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->home_team_id)->name); ?>


                                vs
                                <?php if(App\Models\Team::find($game->away_team_id)->image): ?>
                                    <img src="<?php echo e(App\Models\Team::find($game->away_team_id)->image); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo"
                                        style="max-width: 40px; max-height: auto;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('placeholder.png')); ?>"
                                        alt="<?php echo e(App\Models\Team::find($game->away_team_id)->name); ?> logo" height="50">
                                <?php endif; ?>
                                <?php echo e(App\Models\Team::find($game->away_team_id)->name); ?>


                            </td>
                            <td><?php echo e($game->start); ?></td>
                            <td>
                                <?php if(!$game->finished && $game->start < now()): ?>
                                    <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                    :
                                    <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                                    (Folyamatban)
                                <?php else: ?>
                                    <?php echo e($game->getCurrentScore()['home_team_score']); ?>

                                    :
                                    <?php echo e($game->getCurrentScore()['away_team_score']); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($game->finished ? 'Befejezett' : 'Jövőbeli'); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gombosszabolcs/Library/CloudStorage/OneDrive-EotvosLorandTudomanyegyetem/6. félév/Szerveroldali/Beadando/football/resources/views/games.blade.php ENDPATH**/ ?>