"""Framework for the AI practice sessions"""
