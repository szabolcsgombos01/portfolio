package utolsomiujsag2.snake;
import java.awt.Image;
public class Food extends Sprite  {


    public Food(int x, int y, int width, int height, Image image){
        super(x, y, width, height, image);
    }

}
