package utolsomiujsag2.snake;

public class Main {
    public static void main(String[] args) {
        SnakeGUI gui = new SnakeGUI();
    }
}
