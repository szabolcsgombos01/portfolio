# Runtime terror

## Tower Defense

### Compiling the game:
```text
mvn compile
```
### Building the game:
```text
mvn build
```
### Testing the game:
```text
mvn test
```
### Running the game:
```text
mvn exec:java -Dexec.mainClass=Main
```
