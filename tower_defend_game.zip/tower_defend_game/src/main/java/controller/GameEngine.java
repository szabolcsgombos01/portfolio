package controller;

import model.*;
import model.mapObjects.*;
import model.towers.FirstTower;
import model.towers.SecondTower;
import model.towers.ThirdTower;
import model.towers.Tower;
import model.units.FighterUnit;
import model.units.MountainClimberUnit;
import model.units.Unit;
import view.GUI;
import view.StartingMenu;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class GameEngine {
    public final static int MapSizeX = 10;
    public final static int MapSizeY = 10;
    private final static int MountainCount = 5;
    private final static int BarrackCount = 2;

    private final static int LakeCount = 10;

    private final Random random = new Random();



    public static MapObject[][] map = new MapObject[MapSizeX][MapSizeY];
    private int which_one;
    private int towerType = 0;

    public PlayerDetails player1;
    public PlayerDetails player2;

    private PlayerDetails currentPlayer;

    public GameEngine() {
        init();
    }

    void init() {
        player1 = new PlayerDetails("player1");
        player2 = new PlayerDetails("player2");

        player1.setEnemy(player2);
        player2.setEnemy(player1);

        currentPlayer = player1;

        initMap();
    }

    /**
     * Initializes the map with default MapItems and
     * generates the location of the bases and obstacles randomly
     */
    private void initMap() {
        fillMapWithPlain();
        generateCastles();
        generateMountains();
        generateLakes();
        generateBarracks(1, 4, player1);
        generateBarracks(6, 9, player2);

    }

    /**
     * Generates the barracks for the specified player
     * @param origin The left ending of the player's area where they can build
     * @param bound The right ending of the player's area where they can build
     * @param player The specified player
     */
    private void generateBarracks(int origin, int bound, PlayerDetails player) {
        int count = 0;

        while (count < BarrackCount) {
            int x = random.nextInt(origin, bound);
            int y = random.nextInt(1, 9);

            if (!(map[x][y] instanceof Plain))
                continue;

            Point castle1 = player1.getCastleLocation();
            Point castle2 = player2.getCastleLocation();

            if (castle1.distance(x, y) >= 2 && castle2.distance(x, y) >= 2) {
                Barrack barrack = new Barrack(x, y, player);
                map[x][y] = barrack;
                player.addBarrack(barrack);
                count++;
            }
        }
    }

    /**
     * Generates mountains randomly.
     */
    private void generateMountains() {
        int count = 0;

        while (count < MountainCount) {
            int x = random.nextInt(10);
            int y = random.nextInt(10);

            if (!(map[x][y] instanceof Plain))
                continue;
            
            Point castle1 = player1.getCastleLocation();
            Point castle2 = player2.getCastleLocation();

            if (castle1.distance(x, y) >= 2 && castle2.distance(x, y) >= 2) {
                map[x][y] = new Mountain(x, y);
                count++;
            }
        }
    }

    /**
     * Generates lakes randomly.
     */
    private void generateLakes() {
        int count = 0;

        while (count < LakeCount) {
            int x = random.nextInt(10);
            int y = random.nextInt(10);

            if (!(map[x][y] instanceof Plain))
                continue;

            Point castle1 = player1.getCastleLocation();
            Point castle2 = player2.getCastleLocation();

            if (castle1.distance(x, y) >= 2 && castle2.distance(x, y) >= 2) {
                map[x][y] = new Lake(x, y);
                count++;
            }
        }
    }


    /**
     * Generates the castles at random locations.
     * They can't be on the same side of the map vertically.
     */
    private void generateCastles() {
        int x1 = random.nextInt(1, 4);
        int y1 = random.nextInt(1, 9);

        int x2 = random.nextInt(6, 9);
        int y2 = random.nextInt(1, 9);

        Castle castle1 = new Castle(x1, y1, player1);
        Castle castle2 = new Castle(x2, y2, player2);

        map[x1][y1] = castle1;
        map[x2][y2] = castle2;

        player1.setCastle(castle1);
        player2.setCastle(castle2);
    }

    /**
     * Fills the map with Plain mapobjects
     */
    private void fillMapWithPlain() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                map[i][j] = new Plain(i, j);
            }
        }
    }

    boolean isGameOver() {
        return player1.isDead() || player2.isDead();
    }

    /**
     * @return The winner of the game.
     */
    GameResult getWinner() {
        if (!isGameOver())
            throw new GameIsNotOverException("The game is not over yet!");

        if(player1.isDead() && player2.isDead())
            return GameResult.TIE;


        if (!player1.isDead())
            return GameResult.Player1Won;

        return GameResult.Player2Won;
    }

    public MapObject getMapItem(int x, int y){
        return map[x][y];
    }




    public void loadMap(String mapString){
        int x = 0;
        int y = 0;

        currentPlayer = player1;

        player1.setEnemy(player2);
        player2.setEnemy(player1);

        player1.setMoney(100000000);
        player2.setMoney(100000000);

        player1.removeBarracks();
        player2.removeBarracks();

        MapObject[][] map = new MapObject[MapSizeX][MapSizeY];
        for (int i=0; i < 116; i++) {
            if (mapString.charAt(i) == 'm') {
                map[x][y] = new Mountain(x, y);
                y++;
                
            } else if (mapString.charAt(i) == 'l') {
                map[x][y] = new Lake(x, y);
                y++;

            }else if (mapString.charAt(i) == 'b') {
                if (mapString.charAt(i + 1) == '1') {
                    Barrack barrack = new Barrack(x, y, player1);
                    map[x][y] = barrack;
                    player1.addBarrack(barrack);
                } else {
                    Barrack barrack = new Barrack(x, y, player2);
                    map[x][y] = barrack;
                    player2.addBarrack(barrack);
                }
                i++;
                y++;
            } else if (mapString.charAt(i) == 'c') {
                if(mapString.charAt(i+1)=='1'){
                    Castle castle = new Castle(x, y, player1);
                    map[x][y] = castle;
                    player1.setCastle(castle);
                }else{
                    Castle castle = new Castle(x, y, player2);
                    map[x][y] = castle;
                    player2.setCastle(castle);
                }
                i++;
                y++;
            } else if (mapString.charAt(i) == 'p') {
                map[x][y] = new Plain(x, y);
                y++;

            } else if (mapString.charAt(i) == '\n') {
                x++;
                y=0;

            }

        }
        this.map=map;


        x = 0;
        y = 0;


        for(int i=0;i<10;++i){
            for(int j=0;j<10;++j){
                player1.towerMatrix[x][y]=0;
                player2.towerMatrix[x][y]=0;
            }
        }

        player1.removeTowers();
        player2.removeTowers();



        x = 0;
        y = 0;

        for(int i=116;i<226;++i){
            if (mapString.charAt(i) == '1') {
                player1.addTower(new FirstTower(x, y, player1, 20, 20, 3, 100));
                player1.towerMatrix[x][y]=1;
                y++;

            }else if (mapString.charAt(i) == '2') {
                player1.addTower(new SecondTower(x, y, player1, 20, 20, 3, 100));
                player1.towerMatrix[x][y]=2;
                y++;

            }
            else if (mapString.charAt(i) == '3') {
                player1.addTower(new ThirdTower(x, y, player1, 20, 20, 3, 100));
                player1.towerMatrix[x][y]=3;
                y++;

            }
            else if (mapString.charAt(i) == '0') {
                y++;
            }
            else if (mapString.charAt(i) == '\n') {
                x++;
                y=0;

            }
        }

        x = 0;
        y = 0;

        for(int i=226;i<336;++i){
            if (mapString.charAt(i) == '1') {
                player2.addTower(new FirstTower(x, y, player2, 20, 20, 3, 100));
                player2.towerMatrix[x][y]=1;
                y++;

            }else if (mapString.charAt(i) == '2') {
                player2.addTower(new SecondTower(x, y, player2, 20, 20, 3, 100));
                player2.towerMatrix[x][y]=2;
                y++;

            }
            else if (mapString.charAt(i) == '3') {
                player2.addTower(new ThirdTower(x, y, player2, 20, 20, 3, 100));
                player2.towerMatrix[x][y]=3;
                y++;

            }
            else if (mapString.charAt(i) == '0') {
                y++;
            }
            else if (mapString.charAt(i) == '\n') {
                x++;
                y=0;

            }
        }

        player1.removeUnits();
        player2.removeUnits();


        int z=336+1;


        /**
         *Load Unit
         */
        for(int i=336;mapString.charAt(i)!='\n';i=i+3){
            if(mapString.charAt(i)=='f'){
                player1.addUnitByLoad(new FighterUnit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player1,this));
            }else if(mapString.charAt(i)=='m'){
                player1.addUnitByLoad(new MountainClimberUnit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player1,this));
            }else{
                player1.addUnitByLoad(new Unit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player1,this));
            }
            z=i+4;
        }

        for(int i=z;mapString.charAt(i)!='\n';i=i+3){
            if(mapString.charAt(i)=='f'){
                player2.addUnitByLoad(new FighterUnit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player2,player1,this));
            }else if(mapString.charAt(i)=='m'){
                player2.addUnitByLoad(new MountainClimberUnit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player2,player1,this));
            }else{
                player2.addUnitByLoad(new Unit(Character.getNumericValue(mapString.charAt(i+1)), Character.getNumericValue(mapString.charAt(i+2)), player2, player1,this));
            }
            z = i +3;
        }

        ++z;

        /**
         *Load money
         */
        String money = "";
        for(int i = z ;mapString.charAt(i)!='\n' ; i++)
        {
            money += mapString.charAt(i);
            z = i+2;

        }
        player1.setMoney(Integer.parseInt(money) );
        money = "";
        for(int i = z ;mapString.charAt(i)!='\n' ; i++)
        {
            money += mapString.charAt(i);
            z = i +2;

        }
        player2.setMoney(Integer.parseInt(money) );
        if(mapString.charAt(z) == 1)
        {
            currentPlayer = player1;
        }
        else
        {
            currentPlayer = player2;
        }
        z = z +2;
        String hp = "";
        for(int i = z ;mapString.charAt(i)!='\n' ; i++)
        {
            hp += mapString.charAt(i);
            z = i +2;

        }
        player1.setHealthPoint(Integer.parseInt(hp));
        hp = "";
        for(int i = z ;mapString.charAt(i)!='\n' ; i++)
        {
            hp += mapString.charAt(i);
            z = i +2;

        }
        player2.setHealthPoint(Integer.parseInt(hp));
        System.out.println("load done");
    }


    public int getMapSizeX() {
        return MapSizeX;
    }

    public int getMapSizeY() {
        return MapSizeY;
    }





    public String mapToString(){
        String result="";
        for(int i = 0 ;  i < getMapSizeX() ; i++ )
        {
            for(int j = 0; j < getMapSizeY() ; j++)
            {

                if ((map[i][j] instanceof Mountain))
                {
                    result=result+"m";
                }
                else if ((map[i][j] instanceof Barrack))
                {
                    result=result+"b";
                    if(player1.getBarracks().get(0) == map[i][j] || player1.getBarracks().get(1) == map[i][j]) {
                        result = result + "1";
                    }
                    else{
                            result=result+"2";
                        }
                }
                else if ((map[i][j] instanceof Lake))
                {
                    result=result+"l";
                }
                else if(map[i][j] instanceof Castle)
                {
                    result=result+"c";
                    if(player1.getCastle() == map[i][j]){
                        result=result+"1";
                    }else{
                        result=result+"2";
                    }
                }
                else{
                    result=result+"p";
                }
            }
            result=result+"\n";
        }
        result+=player1.towersToString();
        result+=player2.towersToString();
        result+=player1.unitsToString();
        result+=player2.unitsToString();
        result+=player1.getMoney();
        result+="\n";
        result+=player2.getMoney();
        result+="\n";
        result+= which_one;
        result+="\n";
        result+= player1.getHealthPoints();
        result+="\n";
        result+= player2.getHealthPoints();

        return result;
    }

    /**
     * Returns the number of units at a specific point
     * @param i The y coordinate
     * @param j The x coordinate
     * @return the number of units at that point
     */
    public int getNumberOfUnitsAt(int i, int j){
        return player1.getNumberOfUnitsAt(i, j) +
               player2.getNumberOfUnitsAt(i, j);
    }

    public java.util.List<Unit> getUnitsAt(int i, int j){
        java.util.List<Unit> newList = new ArrayList<Unit>(player1.getUnitsAt(i, j));
        newList.addAll(player2.getUnitsAt(i, j));

        return newList;
    }

    public java.util.List<Tower> getTowersAt(int i, int j){
        java.util.List<Tower> newList = new ArrayList<Tower>(player1.getTowersAt(i, j));
        newList.addAll(player2.getTowersAt(i, j));

        return newList;
    }

    /**
     * Returns the number of towers at a specific point
     * @param i The y coordinate
     * @param j The x coordinate
     * @return the number of towers at that point
     */
    public int getNumberOfTowersAt(int i, int j){
        return player1.getNumberOfTowersAt(i, j) +
                player2.getNumberOfTowersAt(i, j);
    }

    public PlayerDetails getCurrentPlayer() {
        return currentPlayer;
    }

    /**
     * Changes the player currently at turn to build/train units.
     * Player will be changed to null if the building stage is over.
     */
    public void changeCurrentPlayer(){
        if(currentPlayer == player1){
            which_one = 2;
            currentPlayer = player2;
        } else if (currentPlayer == player2) {
            // This indicates the the current gameState is "Fight"
            // and neither of the players are required to build at the moment
            currentPlayer = null;
            fight();
        } else {
            which_one = 1;
            currentPlayer = player1;
        }

    }

    /**
     * Helper method that returns that number of units
     * that are alive
     * @return The number of units that are alive.
     */
    private int getNumberOfALiveUnits() {
        return player1.getNumberOfUnitsAlive()
                + player2.getNumberOfUnitsAlive();
    }

    /**
     * Handles the fight stage of the game
     */
    private void fight() {

        player1.moveUnits();
        player2.moveUnits();

        player1.attackWithTowers();
        player2.attackWithTowers();

        player1.gainMoney();
        player2.gainMoney();

        if (!isGameOver()){
            changeCurrentPlayer();
        }
        else{
            String s;
            if(getWinner()==GameResult.Player1Won){
                s = "Player1 won the game";
            }else if(getWinner()==GameResult.Player2Won){
                s = "Player2 won the game";
            }else{
                s = "It's a tie";
            }

            final String html = "<html><body style='width: %1spx'>%1s";
            JOptionPane.showMessageDialog(
                    null, String.format(html, 300, s),"Game over",JOptionPane.INFORMATION_MESSAGE);

            GUI.getFrame().dispose();

            StartingMenu swingControlDemo = new StartingMenu();
            swingControlDemo.showButtonDemo();
        }
    }

    /**
     * Pauses the program for the specified milliseconds
     * @param ms the millisecond
     */
    private void wait(int ms) {
        try{
            Thread.sleep(ms);
        }
        catch(InterruptedException ex){
            Thread.currentThread().interrupt();
        }
    }

    public int getTowerType(){
        return this.towerType;
    }

    public void setTowerType(int towerType){
        this.towerType = towerType;
    }

    public int getPlayer1HealthPoints(){
        return player1.getHealthPoints();
    }

    public Point getPlayer1CastleLocation(){
        return player1.getCastleLocation();
    }

    public int getPlayer2HealthPoints(){
        return player2.getHealthPoints();
    }

    public Point getPlayer2CastleLocation(){
        return player2.getCastleLocation();
    }

    public static MapObject[][] getMap() {
        return map;
    }
}