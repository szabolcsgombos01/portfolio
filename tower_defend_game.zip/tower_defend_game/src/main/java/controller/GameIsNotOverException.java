package controller;

public class GameIsNotOverException extends RuntimeException {
    public GameIsNotOverException(String message) {
        super(message);
    }
}
