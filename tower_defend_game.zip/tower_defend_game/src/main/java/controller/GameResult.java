package controller;

public enum GameResult {
    TIE, Player1Won, Player2Won
}
