package model;

import model.mapObjects.Barrack;
import model.mapObjects.Castle;
import model.towers.Tower;
import model.units.FighterUnit;
import model.units.MountainClimberUnit;
import model.units.TowerDestroyerUnit;
import model.units.Unit;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class PlayerDetails {
    private String playerName;
    private int money = 2000;
    private int numberOfUnitsTrained = 0;
    private int killedUnits = 0;
    private Castle castle;
    private Barrack barrack;
    private final List<Barrack> barracks = new ArrayList<>();
    private final List<Tower> towers = new ArrayList<>();
    private List<Unit> units = new ArrayList<>();
    private PlayerDetails enemy;
    public int[][] towerMatrix = {  {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0},
                                    {0,0,0,0,0,0,0,0,0,0}};


    public PlayerDetails(String playerName){
        this.playerName = playerName;
    }

    public void addBarrack(Barrack barrack) {
        barracks.add(barrack);
    }

    public boolean isDead(){
        return !castle.isAlive();
    }

    public Point getCastleLocation() {
        return castle.getLocation();
    }

    public void setCastle(Castle castle) {
        this.castle = castle;
    }
    public  void setBarracks(Barrack barrack)
    {
        this.barrack = barrack;
    }

    public Castle getCastle() {
        return castle;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money)
    {
        this.money = money;
    }

    public int getNumberOfUnitsAt(int i, int j){
        return units.stream()
                .filter( u -> u.getX() == i && u.getY() == j )
                .toList()
                .size();
    }

    public int getNumberOfUnitsAlive(){
        return units.size();
    }

    public List<Unit> getUnitsAt(int i, int j){
        return units.stream()
                .filter( u -> u.getX() == i && u.getY() == j )
                .toList();
    }

    public int getNumberOfTowersAt(int i, int j){
        return towers.stream()
                .filter( u -> u.getX() == i && u.getY() == j )
                .toList()
                .size();
    }

    public List<Tower> getTowersAt(int i, int j){
        return towers.stream()
                .filter( u -> u.getX() == i && u.getY() == j )
                .toList();
    }

    public Optional<Tower> getTowerAt(Point p){
        return towers.stream()
                .filter( t -> t.getLocation().equals(p) )
                .findFirst();
    }

    public void addUnit(Unit u){
        if (money >= u.getCost()){
            units.add(u);
            numberOfUnitsTrained++;
            money -= u.getCost();
        }
    }

    public void addUnitByLoad(Unit u){
        units.add(u);
        numberOfUnitsTrained++;
    }

    public void addTower(Tower t){
        if (money >= t.getCost()){
            towers.add(t);
            money -= t.getCost();
        }
    }

    public Point getRandomBarrackLocation() {
        Random r = new Random();
        int index = r.nextInt(0, barracks.size());
        return barracks.get(index).getLocation();
    }

    public void incrementKilledUnits() {
        killedUnits++;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getHealthPoints() {
        return castle.getHealth();
    }

    public void setHealthPoint(int healt)
    {
        castle.setHealth(healt);
    }

    public int getCastleX(){
        return castle.getX();
    }

    public int getCastleY(){
        return castle.getY();
    }

    public void generateOptimalPaths() {
        for(int i=0;i<units.size();++i){
            units.get(i).findOptimalPath();
        }
    }

    /**
     * Moves the units to next MapObject
     */
    public void moveUnits() {
        generateOptimalPaths();

        units.forEach(unit -> {
            unit.move();

            if (unit.getLocation().equals(enemy.getCastleLocation())){
                unit.attack(enemy.getCastle());
                enemy.incrementKilledUnits();
            }

            if (unit instanceof TowerDestroyerUnit u){
                Point loc = unit.getLocation();
                Optional<Tower> tower = getTowerAt(loc);

                tower.ifPresent(u::attack);
            }

            cleanUpUnits();
        });
    }

    public void setEnemy(PlayerDetails enemy){
        this.enemy = enemy;
    }

    public PlayerDetails getEnemy(){
        return this.enemy;
    }

    public void attackWithTowers() {
        List<Unit> enemyUnits = enemy.getUnits();

        towers.forEach( tower -> {
            enemyUnits.forEach( unit -> {
                if (unit.isAlive() && tower.canAttack(unit)){
                    tower.attack(unit);
                    if (!unit.isAlive())
                        killedUnits++;
                }
            });
            enemy.cleanUpUnits();
        });
    }

    public void gainMoney() {
        money += killedUnits * 10 + numberOfUnitsTrained * 10;
        killedUnits = 0;
    }

    /**
     * Removes the units from the list that are dead
     */
    private void cleanUpUnits() {
        List<Unit> unitsTemp = units.stream()
                .filter(Unit::isAlive)
                .toList();
        units = new ArrayList<>(unitsTemp);
    }

    private List<Unit> getUnits() {
        return new ArrayList<>(units);
    }


    public String towersToString(){
        String result="";
        for(int x=0;x<10;++x){
            for(int y=0;y<10;++y){

               if(towerMatrix[x][y]==1){
                   result+="1";
               }else if(towerMatrix[x][y]==2){
                   result+="2";
               }else if(towerMatrix[x][y]==3){
                   result+="3";
               }else{
                   result+="0";
               }

            }
            result+='\n';
        }

        return result;
    }

    public String unitsToString(){
        String result="";

        for(int i=0;i<units.size();++i){
            if(units.get(i) instanceof FighterUnit){
                result+="f"+units.get(i).getX()+units.get(i).getY();
            }else if(units.get(i) instanceof MountainClimberUnit) {
                result += "m" + units.get(i).getX() + units.get(i).getY();
            }else{
                result += "s" + units.get(i).getX() + units.get(i).getY();
            }

        }

        return result+"\n";
    }

    public void removeUnits(){
        units.clear();
    }

    public void removeTowers(){
        towers.clear();
    }

    public void removeBarracks(){
        barracks.clear();
    }


    public List<Barrack> getBarracks() {
        return barracks;
    }

    public int getNumberOfUnitsTrained() {
        return numberOfUnitsTrained;
    }

    public int getKilledUnits() {
        return killedUnits;
    }
}
