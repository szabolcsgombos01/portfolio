package model.mapObjects;

import model.PlayerDetails;

public class Barrack extends MapObject {
    private final PlayerDetails player;

    public Barrack(int x, int y, PlayerDetails player) {
        super(x, y);
        this.player = player;
    }
}
