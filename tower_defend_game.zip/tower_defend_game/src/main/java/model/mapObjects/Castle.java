package model.mapObjects;

import model.PlayerDetails;
import model.units.Unit;

public class Castle extends MapObject {

    private PlayerDetails player;
    private int health = 100;

    public Castle(int x, int y, PlayerDetails player){
        super(x, y);
        this.player = player;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health)
    {
        this.health = health;
    }

    public void attacked(Unit unit) {
        health -= unit.getAttack();
    }


}
