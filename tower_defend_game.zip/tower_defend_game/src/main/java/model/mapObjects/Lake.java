package model.mapObjects;

public class Lake extends Obstacle {

    public Lake(int x, int y) {
        super(x, y);
    }
}
