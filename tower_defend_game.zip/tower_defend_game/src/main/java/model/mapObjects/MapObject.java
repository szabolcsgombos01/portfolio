package model.mapObjects;

import java.awt.*;

public abstract class MapObject {
    private final Point location;

    protected MapObject(int x, int y){
        this.location = new Point(x, y);
    }

    public Point getLocation(){
        return (Point) location.clone();
    }

    public int getX() {
        return (int) location.getX();
    }

    public int getY() {
        return (int) location.getY();
    }

}
