package model.mapObjects;

public class Mountain extends Obstacle {

    public Mountain(int x, int y) {
        super(x, y);
    }
}
