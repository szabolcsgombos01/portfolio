package model.mapObjects;

public abstract class Obstacle extends MapObject {

    protected Obstacle(int x, int y){
        super(x, y);
    }
}
