package model.mapObjects;

public class Plain extends MapObject {
    public Plain(int x, int y) {
        super(x, y);
    }
}
