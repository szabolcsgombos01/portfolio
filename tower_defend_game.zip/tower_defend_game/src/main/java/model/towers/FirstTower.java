package model.towers;

import model.PlayerDetails;

public class FirstTower extends Tower{
    public FirstTower(int x, int y, PlayerDetails player , int attack, int attackSpeed, int range, int cost) {
        super(x, y, player, 15 , 10 , 15, 200);
    }

    @Override
    public int getCost()
    {
        return 200;
    }

}
