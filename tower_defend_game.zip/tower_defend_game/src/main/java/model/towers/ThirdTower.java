package model.towers;

import model.PlayerDetails;

public class ThirdTower extends Tower{
    public ThirdTower(int x, int y, PlayerDetails player , int attack, int attackSpeed, int range, int cost) {
        super(x, y, player, 5 , 20 , 12, 300);
    }

    @Override
    public int getCost()
    {
        return 300;
    }
}
