package model.towers;

import model.PlayerDetails;
import model.mapObjects.MapObject;
import model.units.TowerDestroyerUnit;
import model.units.Unit;

public class Tower extends MapObject {

    private final PlayerDetails player;
    public int health = 100;
    private final int attack;
    private final int attackSpeed;
    private final int range;
    private final int cost;

    public Tower(int x, int y, PlayerDetails player, int attack, int attackSpeed, int range, int cost) {
        super(x, y);
        this.player = player;
        this.attack = attack;
        this.attackSpeed = attackSpeed;
        this.range = range;
        this.cost = cost;
    }

    public void attacked(TowerDestroyerUnit unit) {
        health -= unit.getAttack();
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAttack() {
        return attack;
    }

    public int getAttackSpeed() {
        return attackSpeed;
    }

    public int getRange() {
        return range;
    }

    public int getCost() {
        return cost;
    }

    public PlayerDetails getPlayer() {
        return player;
    }

    /**
     * Decides whether the unit is in the range of the tower
     * @param unit The unit in question
     * @return whether the unit can be attacked
     */
    public boolean canAttack(Unit unit) {

        return getLocation().distance(unit.getLocation()) <= range;
    }

    public void attack(Unit unit) {
        unit.attacked(attack);
    }
}
