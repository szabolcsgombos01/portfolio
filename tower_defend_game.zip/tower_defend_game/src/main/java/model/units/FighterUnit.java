package model.units;

import controller.GameEngine;
import model.PlayerDetails;

public class FighterUnit extends Unit {

    public FighterUnit(int x, int y, PlayerDetails player) {
        super(x, y, player, 100);
    }

    public FighterUnit(int x, int y, PlayerDetails player,GameEngine gameEngine) {
        super(x, y, player, 100, gameEngine);
    }

    public FighterUnit(int x, int y, PlayerDetails player,PlayerDetails enemy,GameEngine gameEngine) {
        super(x, y, player, 100, enemy, gameEngine);
    }


    @Override
    public int getCost() {
        return 100;
    }
}
