package model.units;

import controller.GameEngine;
import model.units.util.Dijkstra;
import model.units.util.Graph;
import model.PlayerDetails;
import model.mapObjects.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MountainClimberUnit extends Unit {

    private boolean wait = false;

    public MountainClimberUnit(int x, int y, PlayerDetails player) {
        super(x, y, player, 50);
    }

    public MountainClimberUnit(int x, int y, PlayerDetails player,GameEngine gameEngine) {
        super(x, y, player, 50, gameEngine);
    }

    public MountainClimberUnit(int x, int y, PlayerDetails player,PlayerDetails enemy,GameEngine gameEngine) {
        super(x, y, player, 50,enemy, gameEngine);
    }

    @Override
    public int getCost() {
        return 50;
    }

    @Override
    public void move(){
        if(!wait){
            if(location.getX()!=enemy.getCastle().getX() || location.getY()!=enemy.getCastle().getY()){
                Point newLocation = new Point();
                if (optimalPath.size()>1){
                    newLocation = optimalPath.get(1);
                    optimalPath.remove(0);
                }
                this.location=newLocation;
                if(GameEngine.getMap()[newLocation.x][newLocation.y] instanceof Mountain || GameEngine.getMap()[newLocation.x][newLocation.y] instanceof Lake) {
                    wait=true;
                }
            }
        }
        else{
            wait=false;
        }


    }


    @Override
    public void findOptimalPath() {
        int x=this.getX();
        int y=this.getY();
        Castle enemyCastle = enemy.getCastle();
        System.out.println(enemyCastle.getX()+" "+enemyCastle.getY());
        MapObject[][] map = GameEngine.getMap();


        Graph g = new Graph();

        for(int i=0;i<10;++i){
            for(int j=0;j<9;++j){
                if((map[i][j] instanceof Plain || map[i][j] instanceof Castle) && (map[i][j+1] instanceof Plain || map[i][j+1] instanceof Castle) && player.towerMatrix[i][j+1]==0 && enemy.towerMatrix[i][j+1]==0 && player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0){
                    g.addEdge((i*10)+j,(i*10)+(j+1),1);
                }else if(player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0 && player.towerMatrix[i][j+1]==0 && enemy.towerMatrix[i][j+1]==0){
                    g.addEdge((i*10)+j,(i*10)+(j+1),2);
                }
            }
        }

        for(int i=0;i<9;++i){
            for(int j=0;j<10;++j){
                if((map[i][j] instanceof Plain || map[i][j] instanceof Castle) && (map[i+1][j] instanceof Plain || map[i+1][j] instanceof Castle) && player.towerMatrix[i+1][j]==0 && enemy.towerMatrix[i+1][j]==0 && player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0){
                    g.addEdge((i*10)+j,((i+1)*10)+j,1);
                }else if(player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0 && player.towerMatrix[i+1][j]==0 && enemy.towerMatrix[i+1][j]==0){
                    g.addEdge((i*10)+j,((i+1)*10)+j,2);
                }
            }
        }

        int[][] adjMatrix = g.getAdjMatrix();


        Dijkstra d = new Dijkstra();

        d.dijkstra(adjMatrix, y+x*10,enemyCastle.getX()*10+enemyCastle.getY(),false);

        List<Integer> parents = d.getParentList();

        d.clearParentList();

        List<Point> optimalPath = new ArrayList<>();

        for(int i=0;i<parents.size();i++){
            x=parents.get(i)/10;
            y=parents.get(i)-x*10;
            optimalPath.add(new Point(x,y));
        }

        setOptimalPath(optimalPath);

    }
}
