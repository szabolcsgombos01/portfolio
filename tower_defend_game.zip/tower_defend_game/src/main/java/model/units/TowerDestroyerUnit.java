package model.units;

import controller.GameEngine;
import model.PlayerDetails;
import model.towers.Tower;

public class TowerDestroyerUnit extends Unit
{
    public TowerDestroyerUnit(int x, int y, PlayerDetails player, GameEngine gameEngine) {
        super(x, y, player,gameEngine);
    }

    public void attack(Tower t) {
        t.attacked(this);

        this.setHealth(0);
    }
}
