package model.units;


import controller.GameEngine;
import model.units.util.Dijkstra;
import model.units.util.Graph;
import model.PlayerDetails;
import model.mapObjects.Barrack;
import model.mapObjects.Castle;
import model.mapObjects.MapObject;
import model.mapObjects.Plain;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Unit{
    protected Point location;
    public final PlayerDetails player;
    private final int speed = 1;
    private int health = 100;
    private final int attack = 25;
    public List<Point> optimalPath;
    private int cost = 25;

    private GameEngine gameEngine;
    public PlayerDetails enemy;

    public Unit(int x, int y, PlayerDetails player) {
        this.location = new Point(x, y);
        this.player = player;
    }

    protected Unit(int x, int y, PlayerDetails player, int cost) {
        this.location = new Point(x, y);
        this.player = player;
        this.cost = cost;

    }

    public Unit(int x, int y, PlayerDetails player,GameEngine gameEngine) {
        this.location = new Point(x, y);
        this.player = player;
        this.gameEngine=gameEngine;
        this.enemy = player.getEnemy();
    }

    public Unit(int x, int y, PlayerDetails player,int cost, PlayerDetails enemy, GameEngine gameEngine) {
        this.location = new Point(x, y);
        this.player = player;
        this.gameEngine=gameEngine;
        this.enemy = enemy;
    }

    public Unit(int x, int y, PlayerDetails player, PlayerDetails enemy, GameEngine gameEngine) {
        this.location = new Point(x, y);
        this.player = player;
        this.gameEngine=gameEngine;
        this.enemy = enemy;
    }



    protected Unit(int x, int y, PlayerDetails player, int cost,GameEngine gameEngine) {
        this.location = new Point(x, y);
        this.player = player;
        this.cost = cost;
        this.gameEngine=gameEngine;
        enemy = gameEngine.getCurrentPlayer().getEnemy();
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void move(){
        if(location.getX()!=enemy.getCastle().getX() || location.getY()!=enemy.getCastle().getY()){
            Point newLocation = new Point();
            if (optimalPath.size()>1){
                newLocation = optimalPath.get(1);
                optimalPath.remove(0);

            }

            this.location=newLocation;
        }

    }

    public void findOptimalPath() {
        int x=this.getX();
        int y=this.getY();
        Castle enemyCastle = enemy.getCastle();
        System.out.println(enemyCastle.getX()+" "+enemyCastle.getY());
        MapObject[][] map = GameEngine.getMap();


        Graph g = new Graph();

        for(int i=0;i<10;++i){
            for(int j=0;j<9;++j){
                if((map[i][j] instanceof Plain || map[i][j] instanceof Castle || map[i][j] instanceof Barrack) && (map[i][j+1] instanceof Plain || map[i][j+1] instanceof Castle || map[i][j+1] instanceof Barrack  ) && player.towerMatrix[i][j+1]==0 && enemy.towerMatrix[i][j+1]==0 && player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0){
                    if (map[i][j] instanceof Barrack && (i != x || j != y))
                        continue;
                    if (map[i][j+1] instanceof Barrack && (i != x || j + 1 != y))
                        continue;
                    g.addEdge((i*10)+j,(i*10)+(j+1),1);
                }
            }
        }

        for(int i=0;i<9;++i){
            for(int j=0;j<10;++j){
                if((map[i][j] instanceof Plain || map[i][j] instanceof Castle || map[i][j] instanceof Barrack) && (map[i+1][j] instanceof Plain || map[i+1][j] instanceof Castle || map[i+1][j] instanceof Barrack) && player.towerMatrix[i+1][j]==0 && enemy.towerMatrix[i+1][j]==0 && player.towerMatrix[i][j]==0 && enemy.towerMatrix[i][j]==0){
                    if (map[i][j] instanceof Barrack && (i != x || j != y))
                        continue;
                    if (map[i+1][j] instanceof Barrack && (i + 1 != x || j != y))
                        continue;
                    g.addEdge((i*10)+j,((i+1)*10)+j,1);
                }
            }
        }

        int[][] adjMatrix = g.getAdjMatrix();


        Dijkstra d = new Dijkstra();

        d.dijkstra(adjMatrix, y+x*10,enemyCastle.getX()*10+enemyCastle.getY(),false);

        List<Integer> parents = d.getParentList();

        d.clearParentList();

        List<Point> optimalPath = new ArrayList<>();

        for(int i=0;i<parents.size();i++){
            x=parents.get(i)/10;
            y=parents.get(i)-x*10;
            optimalPath.add(new Point(x,y));
        }


        setOptimalPath(optimalPath);

    }

    protected void setOptimalPath(List<Point> optimalPath) {
        this.optimalPath = optimalPath;
    }

    public int getX() {
        return (int) location.getX();
    }

    public int getY() {
        return (int) location.getY();
    }

    public PlayerDetails getPlayer() {
        return player;
    }

    public int getSpeed() {
        return speed;
    }

    public int getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }

    public int getCost() {
        return cost;
    }

    protected void setHealth(int health) {
        this.health = health;
    }

    public Point getLocation() {
        return new Point(location);
    }

    public void attacked(int attack) {
        this.health -= attack;
    }

    public void attack(Castle castle) {
        castle.attacked(this);

        this.health = 0;
    }
}
