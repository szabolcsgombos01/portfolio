package model.units.util;

public class Graph {
    private int adjMatrix[][];
    private int numVertices = 100;

    /**
     * Initialize the matrix
     */
    public Graph() {
        adjMatrix = new int[numVertices][numVertices];
    }

    /**
     * Add edges
     * @param i
     * @param j
     * @param weight
     */
    public void addEdge(int i, int j, int weight) {
        adjMatrix[i][j] = weight;
        adjMatrix[j][i] = weight;
    }

    /**
     * Remove edges
     * @param i
     * @param j
     */
    public void removeEdge(int i, int j) {
        adjMatrix[i][j] = 0;
        adjMatrix[j][i] = 0;
    }

    /**
     * Print the matrix
     * @return
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < numVertices; i++)
        {
            s.append(i + ": ");
            for (int j : adjMatrix[i])
            {
                s.append(j  + " ");
            }
            s.append("\n");
        }
        return s.toString();
    }

    public int[][] getAdjMatrix() {
        return adjMatrix;
    }

}