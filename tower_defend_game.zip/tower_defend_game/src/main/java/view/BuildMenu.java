package view;

import model.towers.FirstTower;
import model.towers.SecondTower;
import model.towers.ThirdTower;

import javax.swing.*;
import java.awt.*;

public class BuildMenu extends JPanel {
    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);
    private final Color bGcolor = new Color(40,42,54);

    public BuildMenu() {
        setBackground(bGcolor);
        setForeground(purple);
        setFont(font);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        paintTowers();
    }

    /**
     * Paints the available types of towers.
     */
    private void paintTowers(){
        JPanel tower = new TowerPanel(new FirstTower( -1 , -1 , null , 15 , 10 , 15, 200),
                "Tower LvL 1",
                new ImageIcon("src/main/resources/firsttower.png").getImage());
        add(tower);
        JPanel tower1 = new TowerPanel(new SecondTower( -1 , -1 , null , 30 , 5 , 10, 250),
                "Tower LvL 2",
                new ImageIcon("src/main/resources/secondtower.png").getImage());
        add(tower1);
        JPanel tower2 = new TowerPanel(new ThirdTower( -1 , -1 , null , 5 , 20 , 12, 300),
                "Tower LvL 3",
                new ImageIcon("src/main/resources/thirdtower.png").getImage());
        add(tower2);
    }
}
