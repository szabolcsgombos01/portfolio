package view;

import model.mapObjects.Barrack;
import model.mapObjects.Castle;
import model.mapObjects.MapObject;
import model.mapObjects.Plain;
import model.towers.FirstTower;
import model.towers.SecondTower;
import model.towers.ThirdTower;
import model.units.util.Dijkstra;
import model.units.util.Graph;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class GUI extends JFrame{
    private static JFrame frame;
    private GameWindow gameArea;
    private JPanel panel;

    public GUI(boolean load) {
        frame = new JFrame("Tower Defense Game");
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JMenuBar menuBar = new JMenuBar();

        frame.setJMenuBar(menuBar);
        JMenu gameMenu = new JMenu("Game");
        menuBar.add(gameMenu);
        JMenuItem newGame = new JMenuItem("New Game");
        JMenuItem saveGame = new JMenuItem("Save Game");
        JMenuItem loadGame = new JMenuItem("Load Game");
        JMenuItem exit = new JMenuItem("Exit");

        gameMenu.add(newGame);
        gameMenu.add(saveGame);
        gameMenu.add(loadGame);
        gameMenu.add(exit);

        exit.addActionListener(new ActionListener(){
                                   @Override
                                   public void actionPerformed(ActionEvent e) {
                                       System.exit(0);
                                   }
                               }
        );

        newGame.addActionListener(new ActionListener(){
                                   @Override
                                   public void actionPerformed(ActionEvent e) {
                                       frame.dispose();
                                       GUI gui = new GUI(false);
                                   }
                               }
        );

        loadGame.addActionListener(new ActionListener(){
                                   @Override
                                   public void actionPerformed(ActionEvent e) {

                                       if(e.getSource()==loadGame) {

                                           JFileChooser fileChooser = new JFileChooser();

                                           FileFilter filter = new FileNameExtensionFilter("TXT file", new String[] {"txt"});
                                           fileChooser.setFileFilter(filter);
                                           fileChooser.addChoosableFileFilter(filter);

                                           Path path = Paths.get(".");
                                           Path root = path.getRoot();

                                           /**
                                            * sets current directory
                                            */
                                           fileChooser.setCurrentDirectory(new File(String.valueOf(root)));

                                           /**
                                            * select file to open
                                            */
                                           int response = fileChooser.showOpenDialog(null);


                                           if(response == JFileChooser.APPROVE_OPTION) {
                                               File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                                               System.out.println(file);


                                               String saveString = "";
                                               Scanner myReader = null;
                                               try {
                                                   myReader = new Scanner(file);
                                               } catch (FileNotFoundException ex) {
                                                   ex.printStackTrace();
                                               }
                                               while (myReader.hasNextLine()) {
                                                   saveString += myReader.nextLine();
                                                   saveString += "\n";
                                               }
                                               myReader.close();

                                                System.out.println(saveString);
                                               gameArea.getGameEngine().loadMap(saveString);
                                           }
                                       }

                                   }
                               }
        );

        saveGame.addActionListener(new ActionListener(){
                                       @Override
                                       public void actionPerformed(ActionEvent e) {
                                           if(e.getSource()==saveGame) {

                                               JFileChooser fileChooser = new JFileChooser();

                                               FileFilter filter = new FileNameExtensionFilter("TXT file", new String[] {"txt"});
                                               fileChooser.setFileFilter(filter);
                                               fileChooser.addChoosableFileFilter(filter);

                                               Path path = Paths.get(".");
                                               Path root = path.getRoot();

                                               /**
                                                * sets current directory
                                                */
                                               fileChooser.setCurrentDirectory(new File(String.valueOf(root)));


                                               /**
                                                * select file to save
                                                */
                                               int response = fileChooser.showSaveDialog(null);

                                               if(response == JFileChooser.APPROVE_OPTION) {
                                                   File file = new File(fileChooser.getSelectedFile().getAbsolutePath()+".txt");
                                                   System.out.println(file);

                                                   try {
                                                       new PrintWriter(file);
                                                   } catch (FileNotFoundException ex) {
                                                       ex.printStackTrace();
                                                   }

                                                   try {
                                                       FileWriter mySave = new FileWriter(fileChooser.getSelectedFile().getAbsolutePath()+".txt");
                                                       mySave.write(gameArea.getGameEngine().mapToString());
                                                       mySave.close();
                                                   } catch (IOException ex) {
                                                       ex.printStackTrace();
                                                   }


                                               }
                                           }

                                       }
                                   }
        );

        gameArea = new GameWindow();
        frame.getContentPane().add(gameArea);
        frame.setPreferredSize(new Dimension(1064, 810));
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated((false));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


        if(load){
            JFileChooser fileChooser = new JFileChooser();

            FileFilter filter = new FileNameExtensionFilter("TXT file", new String[] {"txt"});
            fileChooser.setFileFilter(filter);
            fileChooser.addChoosableFileFilter(filter);

            Path path = Paths.get(".");
            Path root = path.getRoot();

            /**
             * sets current directory
             */
            fileChooser.setCurrentDirectory(new File(String.valueOf(root)));

            /**
             * select file to open
             */
            int response = fileChooser.showOpenDialog(null);


            if(response == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                System.out.println(file);


                String saveString = "";
                Scanner myReader = null;
                try {
                    myReader = new Scanner(file);
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }
                while (myReader.hasNextLine()) {
                    saveString += myReader.nextLine();
                    saveString += "\n";
                }
                myReader.close();

                System.out.println(saveString);
                gameArea.getGameEngine().loadMap(saveString);
            }
        }


        frame.addMouseListener(new MouseAdapter() {
            /**
             * provides empty implementation of all
             * MouseListener`s methods, allowing us to
             * override only those which interests us
             * I override only one method for presentation
             * @param e
             */
            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println(e.getX() + "," + e.getY());

                try{
                    if(gameArea.getGameEngine().getNumberOfTowersAt((int)(e.getX()-7)/75,(int)(e.getY()-53)/75)<1 && gameArea.getGameEngine().getMapItem((int)(e.getX()-7)/75,(int)(e.getY()-53)/75) instanceof Plain) {


                        Castle Castle1 = gameArea.getGameEngine().player1.getCastle();
                        Castle Castle2 = gameArea.getGameEngine().player2.getCastle();

                        Barrack Barrack1 = gameArea.getGameEngine().player1.getBarracks().get(0);
                        Barrack Barrack2 = gameArea.getGameEngine().player1.getBarracks().get(1);
                        Barrack Barrack3 = gameArea.getGameEngine().player2.getBarracks().get(0);
                        Barrack Barrack4 = gameArea.getGameEngine().player2.getBarracks().get(1);


                        MapObject[][] map = gameArea.getGameEngine().getMap();

                        Graph g = new Graph();

                        for(int i=0;i<10;++i){
                            for(int j=0;j<9;++j){
                                if(!(((int) (e.getX() - 7) / 75)==i && ((int) (e.getY() - 53) / 75)==j) && !(((int) (e.getX() - 7) / 75)==i && ((int) (e.getY() - 53) / 75)==j) && (map[i][j] instanceof Plain || map[i][j] instanceof Castle || map[i][j] instanceof Barrack) && (map[i][j+1] instanceof Plain || map[i][j+1] instanceof Castle || map[i][j+1] instanceof Barrack) && gameArea.getGameEngine().player1.towerMatrix[i][j+1]==0 && gameArea.getGameEngine().player2.towerMatrix[i][j+1]==0 && gameArea.getGameEngine().player1.towerMatrix[i][j]==0 && gameArea.getGameEngine().player2.towerMatrix[i][j]==0){
                                    System.out.println("1 "+(int) (e.getX() - 7) / 75+"  "+i+"        "+(int) (e.getY() - 53) / 75+"  "+j);
                                    g.addEdge((i*10)+j,(i*10)+(j+1),1);
                                }
                            }
                        }

                        for(int i=0;i<9;++i){
                            for(int j=0;j<10;++j){
                                if(!(((int) (e.getX() - 7) / 75)-1==i && ((int) (e.getY() - 53) / 75)==j) && !(((int) (e.getX() - 7) / 75)==i && ((int) (e.getY() - 53) / 75)==j) && (map[i][j] instanceof Plain || map[i][j] instanceof Castle || map[i][j] instanceof Barrack) && (map[i+1][j] instanceof Plain || map[i+1][j] instanceof Castle || map[i+1][j] instanceof Barrack) && gameArea.getGameEngine().player1.towerMatrix[i+1][j]==0 && gameArea.getGameEngine().player2.towerMatrix[i+1][j]==0 && gameArea.getGameEngine().player1.towerMatrix[i][j]==0 && gameArea.getGameEngine().player2.towerMatrix[i][j]==0){
                                    System.out.println("2 "+(int) (e.getX() - 7) / 75+"  "+i+"        "+(int) (e.getY() - 53) / 75+"  "+j);
                                    g.addEdge((i*10)+j,((i+1)*10)+j,1);
                                }
                            }
                        }

                        int[][] adjMatrix = g.getAdjMatrix();


                        Dijkstra a = new Dijkstra();
                        Dijkstra b = new Dijkstra();
                        Dijkstra c = new Dijkstra();
                        Dijkstra d = new Dijkstra();


                        a.dijkstra(adjMatrix, Barrack1.getY()+Barrack1.getX()*10,Castle2.getX()*10+Castle2.getY(),true);
                        int dista=a.getDistance();
                        b.dijkstra(adjMatrix, Barrack2.getY()+Barrack2.getX()*10,Castle2.getX()*10+Castle2.getY(),true);
                        int distb=b.getDistance();

                        c.dijkstra(adjMatrix, Barrack3.getY()+Barrack3.getX()*10,Castle1.getX()*10+Castle1.getY(),true);
                        int distc=c.getDistance();
                        d.dijkstra(adjMatrix, Barrack4.getY()+Barrack4.getX()*10,Castle1.getX()*10+Castle1.getY(),true);
                        int distd=d.getDistance();

                        System.out.println();
                        System.out.println("a: "+dista);
                        System.out.println("b: "+distb);
                        System.out.println("c: "+distc);
                        System.out.println("d: "+distd);

                        if((dista>-40000000 && dista<40000000) && (distb>-40000000 && distb<40000000) && (distc>-40000000 && distc<40000000) && (distd>-40000000 && distd<40000000)){
                            a.setDistance(0);
                            b.setDistance(0);
                            c.setDistance(0);
                            d.setDistance(0);
                            if(gameArea.getGameEngine().getTowerType()==0){
                                gameArea.getGameEngine().getCurrentPlayer().addTower(new FirstTower((int) (e.getX() - 7) / 75, (int) (e.getY() - 53) / 75, gameArea.getGameEngine().getCurrentPlayer(), 20, 20, 3, 100));
                                gameArea.getGameEngine().getCurrentPlayer().towerMatrix[(int) (e.getX() - 7) / 75][(int) (e.getY() - 53) / 75]=1;
                            }
                            else if(gameArea.getGameEngine().getTowerType()==1){
                                gameArea.getGameEngine().getCurrentPlayer().addTower(new SecondTower((int) (e.getX() - 7) / 75, (int) (e.getY() - 53) / 75, gameArea.getGameEngine().getCurrentPlayer(), 20, 20, 3, 100));
                                gameArea.getGameEngine().getCurrentPlayer().towerMatrix[(int) (e.getX() - 7) / 75][(int) (e.getY() - 53) / 75]=2;
                            }
                            else if(gameArea.getGameEngine().getTowerType()==2){
                                gameArea.getGameEngine().getCurrentPlayer().addTower(new ThirdTower((int) (e.getX() - 7) / 75, (int) (e.getY() - 53) / 75, gameArea.getGameEngine().getCurrentPlayer(), 20, 20, 3, 100));
                                gameArea.getGameEngine().getCurrentPlayer().towerMatrix[(int) (e.getX() - 7) / 75][(int) (e.getY() - 53) / 75]=3;
                            }


                        }


                        }
                }
                catch(Exception s){
                }


            }
        });

    }
    public static JFrame getFrame() {
        return frame;
    }
}


