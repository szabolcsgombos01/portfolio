package view;

import controller.GameEngine;
import model.mapObjects.*;
import model.towers.FirstTower;
import model.towers.SecondTower;
import model.towers.Tower;
import model.units.FighterUnit;
import model.units.MountainClimberUnit;
import model.units.Unit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameWindow extends JPanel {

    private GameEngine gameEngine;
    private Sidebar sidebar;

    private boolean started=false;
    private final int FPS = 2;
    private Timer newFrameTimer;
    private JPanel panel;
    private final Image castle = new ImageIcon("src/main/resources/castle.jpg").getImage();
    private final Image castle2 = new ImageIcon("src/main/resources/castle2.png").getImage();
    private final Image grass = new ImageIcon("src/main/resources/grass.jpg").getImage();
    private final Image mountain = new ImageIcon("src/main/resources/mountain.jpg").getImage();
    private final Image water = new ImageIcon("src/main/resources/water.jpg").getImage();
    private final Image unit = new ImageIcon("src/main/resources/firstunit.png").getImage();
    private final Image unit2 = new ImageIcon("src/main/resources/firstunit2.png").getImage();
    private final Image fighterUnit = new ImageIcon("src/main/resources/thirdunit.png").getImage();
    private final Image fighterUnit2 = new ImageIcon("src/main/resources/thirdunit2.png").getImage();
    private final Image mountainClimberUnit = new ImageIcon("src/main/resources/secondunit.png").getImage();
    private final Image mountainClimberUnit2 = new ImageIcon("src/main/resources/secondunit2.png").getImage();
    private final Image firstTower = new ImageIcon("src/main/resources/firsttower.png").getImage();
    private final Image firstTower2 = new ImageIcon("src/main/resources/firsttower2.png").getImage();
    private final Image secondTower = new ImageIcon("src/main/resources/secondtower.png").getImage();
    private final Image secondTower2 = new ImageIcon("src/main/resources/secondtower2.png").getImage();
    private final Image thirdTower = new ImageIcon("src/main/resources/thirdtower.png").getImage();
    private final Image thirdTower2 = new ImageIcon("src/main/resources/thirdtower2.png").getImage();
    private final Image barrack = new ImageIcon("src/main/resources/barrack.jpg").getImage();

    private final int imageSize = 75;



    public GameWindow(){
        gameEngine = new GameEngine();

        newFrameTimer = new Timer(1000 / FPS, new NewFrameListener());
        newFrameTimer.start();

        setLayout(null);

        setBorder(BorderFactory.createLineBorder(Color.black));

        sidebar = new Sidebar(gameEngine);
        add(sidebar);
    }

    /**
     * kirajzolás
     * @param grphcs
     */
    @Override
    protected void paintComponent(Graphics grphcs) {
        super.paintComponent(grphcs);

        boolean first = true;

        for ( int i = 0; i < GameEngine.MapSizeX; i++ ){
            for ( int j = 0; j < GameEngine.MapSizeY; j++ ){
                MapObject item = gameEngine.getMapItem(i, j);
                Image img;


                if ( item instanceof Plain)
                    img = grass;
                else if ( item instanceof Lake)
                    img = water;
                else if ( item instanceof Mountain)
                    img = mountain;
                else if ( item instanceof Barrack)
                    img = barrack;
                else {
                    if(first){
                        img = castle;
                        first = false;
                    }else{
                        img = castle2;
                    }
                }

                grphcs.drawImage(img, i * 75, j * 75,null);
                paintUnits(i,j, grphcs);
                paintTowers(i,j, grphcs);
            }
        }

        paintHealthBars(grphcs);
    }

    /**
     * Paints the health points of the players above their castles
     * @param grphcs the graphics used
     */
    private void paintHealthBars(Graphics grphcs) {
        int player1HP = gameEngine.getPlayer1HealthPoints();
        Point player1Castle = gameEngine.getPlayer1CastleLocation();

        int player2HP = gameEngine.getPlayer2HealthPoints();
        Point player2Castle = gameEngine.getPlayer2CastleLocation();

        grphcs.setColor(Color.white);
        grphcs.setFont(new Font(Font.MONOSPACED,  Font.BOLD, 14));
        grphcs.drawString("" + player1HP + " / 100",
                (int)player1Castle.getX() * 75, (int)player1Castle.getY() * 75);

        grphcs.drawString("" + player2HP + " / 100",
                (int)player2Castle.getX() * 75, (int)player2Castle.getY() * 75);
    }

    /**
     * Unitok kirajzolása
     * @param itemX
     * @param itemY
     * @param graphics
     */
    private void paintUnits(int itemX,int itemY, Graphics graphics) {
        int x = itemX * imageSize;
        int y = itemY * imageSize;
        int unitCount = gameEngine.getNumberOfUnitsAt(itemX, itemY);

        java.util.List<Unit> units = gameEngine.getUnitsAt(itemX, itemY);

        Image img;

        for (int i = 0; i < unitCount; i++){
            int gridX = i / 3;
            int gridY = i % 3;

            if(units.get(i) instanceof FighterUnit){
                img=fighterUnit;
                if(units.get(i).getPlayer()==gameEngine.player2){
                    img=fighterUnit2;
                }
            }
            else if(units.get(i) instanceof MountainClimberUnit){
                img=mountainClimberUnit;
                if(units.get(i).getPlayer()==gameEngine.player2){
                    img=mountainClimberUnit2;
                }
            }
            else{
                img=unit;
                if(units.get(i).getPlayer()==gameEngine.player2){
                    img=unit2;
                }
            }
            graphics.drawImage(img,
                        x + gridY * (imageSize / 3),
                        y + gridX * (imageSize / 3),
                        imageSize / 3,
                        imageSize / 3,
                    null);

        }
        

    }

    private void paintTowers(int itemX,int itemY, Graphics graphics) {
        int x = itemX * imageSize;
        int y = itemY * imageSize;
        int towerCount = gameEngine.getNumberOfTowersAt(itemX, itemY);

        java.util.List<Tower> towers = gameEngine.getTowersAt(itemX, itemY);

        Image img;

        for (int i = 0; i < towerCount; i++){
            int gridX = i / 3;
            int gridY = i % 3;

            if(towers.get(i) instanceof FirstTower){
                img=firstTower;
                if(towers.get(i).getPlayer()==gameEngine.player2){
                    img=firstTower2;
                }
            }
            else if(towers.get(i) instanceof SecondTower){
                img=secondTower;
                if(towers.get(i).getPlayer()==gameEngine.player2){
                    img=secondTower2;
                }
            }
            else{
                img=thirdTower;
                if(towers.get(i).getPlayer()==gameEngine.player2){
                    img=thirdTower2;
                }
            }


            graphics.drawImage(img,
                    x + gridY * (imageSize),
                    y + gridX * (imageSize),
                    imageSize,
                    imageSize,
                    null);
        }
    }



    class NewFrameListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            repaint();
            sidebar.update();
        }

    }


    public GameEngine getGameEngine() {
        return gameEngine;
    }

}
