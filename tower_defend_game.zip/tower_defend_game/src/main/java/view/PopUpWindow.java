package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PopUpWindow extends JFrame {

    public PopUpWindow(){
        prepareGUI();
    }

    private void prepareGUI(){

        final String s = "Adott egy n × m-es pálya, amelyen mindkét játékos egy előre elhelyezett kastély birtokában kezdi a játékot (jellemzően az átellenes oldalon). A játékosok célja, hogy egységek kiképzésével lerombolják az ellenfél kastélyát, miközben tornyok emelésével megvédik sajátukat. A tornyok megfelelő elhelyezésével az ellenséges egységek labirintusba terelhetőek, kikényszerítve, hogy rájuk tüzelő őrtornyok között haladjanak.";
        final String html = "<html><body style='width: %1spx'>%1s";

        Runnable r = () -> {
            JOptionPane.showMessageDialog(
                    null, String.format(html, 300, s),"Game description",JOptionPane.INFORMATION_MESSAGE);
        };
        SwingUtilities.invokeLater(r);




    }
   }
