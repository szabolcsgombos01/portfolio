package view;

import controller.GameEngine;
import model.units.FighterUnit;
import model.units.MountainClimberUnit;
import model.PlayerDetails;
import model.units.Unit;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Sidebar extends JPanel {
    public GameEngine gameEngine;

    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);
    private final Color bGcolor = new Color(40,42,54);

    private JLabel playerName = new JLabel();
    private JLabel playerMoney = new JLabel();
    private JLabel gameState = new JLabel("Fight");
    private JButton endTurn = new JButton("End turn");

    private JTabbedPane jTabbedPane;

    public Sidebar(GameEngine gameEngine){
        this.gameEngine = gameEngine;

        setLocation(750, 0);
        setSize(new Dimension(300, 764));
        setBackground(bGcolor);
        setVisible(true);
        setBorder(BorderFactory.createLineBorder(Color.black));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setAlignmentX(CENTER_ALIGNMENT);

        fillWithContent();
    }

    private void fillWithContent() {
        PlayerDetails currentPlayer = gameEngine.getCurrentPlayer();

        addText(gameState, "Fight");
        printPlayerDetails(currentPlayer);

        endTurn.setAlignmentX(CENTER_ALIGNMENT);
        endTurn.setAlignmentY(CENTER_ALIGNMENT);

        add(endTurn);

        endTurn.addActionListener(new ActionListener(){
                                   @Override
                                   public void actionPerformed(ActionEvent e) {
                                       gameEngine.changeCurrentPlayer();

                                   }
                               }
        );

        showTabs();
    }

    private void showTabs() {
        jTabbedPane = new JTabbedPane();
        JPanel buildMenu = new BuildMenu();
        JPanel unitMenu = new UnitMenu();

        jTabbedPane.setBackground(bGcolor);
        jTabbedPane.setBorder(new EmptyBorder(50, 0, 0, 0));
        jTabbedPane.setForeground(purple);
        jTabbedPane.add("Build Menu", buildMenu);
        jTabbedPane.add("Unit Menu", unitMenu);

        add(jTabbedPane);

        jTabbedPane.addMouseListener(new MouseAdapter() {// provides empty implementation of all
            // MouseListener`s methods, allowing us to
            // override only those which interests us
            @Override //I override only one method for presentation
            public void mousePressed(MouseEvent e) {
                System.out.println(e.getX() + "," + e.getY());
                PlayerDetails player = gameEngine.getCurrentPlayer();
                Point loc = player.getRandomBarrackLocation();

                if(jTabbedPane.getSelectedIndex()==1){

                    /**
                     * Simple Unit
                     */
                    if (e.getY() >= 120 && e.getY() <= 304) {
                        gameEngine.getCurrentPlayer().addUnit(new Unit((int)loc.getX(), (int)loc.getY(), gameEngine.getCurrentPlayer(),gameEngine));
                    }

                    /**
                     * Mountain Climber Unit
                     */

                    if (e.getY() >= 310 && e.getY() <= 488) {
                        gameEngine.getCurrentPlayer().addUnit(new MountainClimberUnit((int)loc.getX(), (int)loc.getY(), gameEngine.getCurrentPlayer(), gameEngine));
                    }


                    /**
                     * Fighter Unit
                     */

                    if (e.getY() >= 492 && e.getY() <= 662) {
                        gameEngine.getCurrentPlayer().addUnit(new FighterUnit((int)loc.getX(), (int)loc.getY(), gameEngine.getCurrentPlayer(), gameEngine));
                    }

                }
                else
                {
                    /**
                     * Tower 1
                     */
                    if (e.getY() >= 120 && e.getY() <= 304) {
                        gameEngine.setTowerType(0);
                    }

                    /**
                     * Tower 2
                     */
                    if (e.getY() >= 310 && e.getY() <= 488) {
                        gameEngine.setTowerType(1);
                    }


                    /**
                     * Tower 3
                     */
                    if (e.getY() >= 492 && e.getY() <= 662) {
                        gameEngine.setTowerType(2);
                    }

                }


            }
        });

    }

    private void printPlayerDetails(PlayerDetails currentPlayer) {
        addText(playerName, "Current player:    " + currentPlayer.getPlayerName());

        int money = currentPlayer.getMoney();
        addText(playerMoney, "Money:    " + money);

    }

    private void addText(JLabel label, String text){

        label.setBorder(new EmptyBorder(10, 0, 10, 0));
        label.setAlignmentX(CENTER_ALIGNMENT);
        label.setAlignmentY(CENTER_ALIGNMENT);
        label.setForeground(purple);
        label.setFont(font);
        add(label);

    }

    /**
     * Updates the Sidebar ui with the values of the current player
     * Certain parts are hidden during the fighting stage
     */
    public void update(){
        PlayerDetails currentPlayer = gameEngine.getCurrentPlayer();
        boolean isNotFight = currentPlayer != null;

        playerName.setVisible(isNotFight);
        playerMoney.setVisible(isNotFight);
        jTabbedPane.setVisible(isNotFight);
        gameState.setVisible(!isNotFight);
        endTurn.setVisible(isNotFight);

        if (isNotFight) {
            playerName.setText("Current player:    " + currentPlayer.getPlayerName());
            playerMoney.setText("Money:    " + currentPlayer.getMoney());
        }
    }
}
