package view;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StartingMenu extends JFrame{
    private JFrame frame;
    private JLabel headerLabel;
    private JLabel statusLabel;
    private JPanel controlPanel;
    public StartingMenu(){
        prepareGUI();
    }
    private GameWindow gameArea = new GameWindow();
    private final Color bGcolor = new Color(40,42,54);
    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);

    private void prepareGUI(){
        frame = new JFrame("Tower Defense Game Main Menu");
        UIManager.put("JFrame.activeTitleBackground", bGcolor);
        frame.setPreferredSize(new Dimension(764, 810));
        frame.getContentPane().setBackground(bGcolor);
        frame.getContentPane().setForeground(purple);
        setBackground(bGcolor);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setLayout(new GridLayout(3, 1));
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });
        headerLabel = new JLabel("", JLabel.CENTER);
        statusLabel = new JLabel("",JLabel.CENTER);
        statusLabel.setSize(350,100);
        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());
        frame.add(headerLabel);
        frame.add(controlPanel);
        frame.add(statusLabel);
        controlPanel.setBackground(bGcolor);
        frame.pack();
        frame.setLocationRelativeTo(null);

        frame.setVisible(true);
    }
    public void showButtonDemo(){
        headerLabel.setText("Tower Defense Game");
        headerLabel.setForeground(purple);
        headerLabel.setFont( new Font("Serif", Font.ITALIC, 36));
        JButton newGameButton = new JButton("New Game");
        JButton loadGameButton = new JButton("Load Game");
        JButton exitButton = new JButton("Exit");
        newGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                GUI gui = new GUI(false);
                PopUpWindow popUpWindow = new PopUpWindow();
            }
        });

        loadGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                GUI gui = new GUI(true);

            }
        });



        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        controlPanel.add(newGameButton);
        controlPanel.add(loadGameButton);
        controlPanel.add(exitButton);
        frame.setVisible(true);
    }
}
