package view;

import model.towers.Tower;
import model.units.Unit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class TowerPanel extends JPanel {
    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);
    private final Color bGcolor = new Color(40,42,54);

    //private final Image towerEgy = new ImageIcon("src/main/resources/tower_egy.png").getImage();
    private final Image towerImg;
    private final Tower tower;
    private final String name;

    public TowerPanel(Tower tower , String name , Image towertImg){
        //this.towerType = new Tower(0,0,null,10,10,10,100) {};
        this.towerImg = towertImg;
        this.tower = tower;
        this.name = name;
        setOpaque(false);
        setForeground(purple);
        setFont(font);
        setBorder(BorderFactory.createLineBorder(Color.CYAN));
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        drawCenteredString(g, name, 40);
        g.drawImage(towerImg, 110, 45, null);
        drawCenteredString(g, "Cost: " + tower.getCost(), 135);

    }

    /**
     * Draws the specified text centered on the screen.
     * @param g The graphics used
     * @param text  The text to be drawn
     * @param y The y coordinate where the painting should start
     */
    public void drawCenteredString(Graphics g, String text, int y) {
        FontMetrics metrics = g.getFontMetrics(font);
        int x = ( 300 - metrics.stringWidth(text)) / 2;
        g.drawString(text, x, y);
    }




}
