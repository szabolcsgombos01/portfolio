package view;

import model.units.FighterUnit;
import model.units.MountainClimberUnit;
import model.units.Unit;
import javax.swing.*;
import java.awt.*;

public class UnitMenu extends JPanel {
    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);
    private final Color bGcolor = new Color(40,42,54);





    public UnitMenu() {
        setBackground(bGcolor);
        setForeground(purple);
        setFont(font);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));





        paintUnits();

    }

    /**
     * Paints the available types of units
     */
    private void paintUnits(){
        JPanel unit1 =
                new UnitPanel(new Unit(-1, -1, null),
                        "Simple Unit",
                        new ImageIcon("src/main/resources/firstunit.png").getImage());
        add(unit1);
        JPanel unit2 =
                new UnitPanel(new MountainClimberUnit(-1, -1, null),
                        "Mountain Climber Unit",
                              new ImageIcon("src/main/resources/secondunit.png").getImage());

        add(unit2);
        JPanel unit3 =
                new UnitPanel(new FighterUnit(-1, -1, null),
                        "Fighter Unit",
                              new ImageIcon("src/main/resources/thirdunit.png").getImage());
        add(unit3);



    }



}
