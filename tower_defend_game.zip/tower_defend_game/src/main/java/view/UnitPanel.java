package view;

import model.units.Unit;

import javax.swing.*;
import java.awt.*;

public class UnitPanel extends JPanel {
    private final Color purple = new Color(189,147,249);
    private final Font font = new Font(Font.MONOSPACED,  Font.PLAIN, 16);
    private final Image unitImg;


    private final Unit unit;
    private final String name;

    public UnitPanel(Unit unit, String name, Image unitImg) {
        this.unit = unit;
        this.name = name;
        this.unitImg = unitImg;

        setOpaque(false);
        setForeground(purple);
        setFont(font);
        setBorder(BorderFactory.createLineBorder(Color.CYAN));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        drawCenteredString(g, name, 40);
        g.drawImage(unitImg, 115, 45, null);
        drawCenteredString(g, "Cost: " + unit.getCost(), 135);

    }

    /**
     * Draws the specified text centered on the screen.
     * @param g The graphics used
     * @param text  The text to be drawn
     * @param y The y coordinate where the painting should start
     */
    public void drawCenteredString(Graphics g, String text, int y) {
        FontMetrics metrics = g.getFontMetrics(font);
        int x = ( 300 - metrics.stringWidth(text)) / 2;
        g.drawString(text, x, y);
    }
}
