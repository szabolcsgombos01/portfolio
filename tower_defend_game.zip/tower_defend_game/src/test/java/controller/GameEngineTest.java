package controller;

import model.*;
import model.mapObjects.Barrack;
import model.mapObjects.Lake;
import model.mapObjects.MapObject;
import model.mapObjects.Mountain;
import model.towers.Tower;
import model.units.FighterUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class GameEngineTest {
    private GameEngine gameEngine;

    @BeforeEach
    public void setUp(){
       gameEngine = new GameEngine();
    }

    @Test
    public void isGameOver() {
        assertFalse(gameEngine.isGameOver());
    }

    @Test
    public void getWinner() {
        assertThrows(GameIsNotOverException.class, gameEngine::getWinner);
    }

    @Test
    public void castleGeneration() {
        assertNotEquals(gameEngine.getPlayer1CastleLocation(),
                        gameEngine.getPlayer2CastleLocation());

    }

    @Test
    public void mapGeneration() {
        MapObject[][] map = GameEngine.map;
        Point castle1Loc = gameEngine.getPlayer1CastleLocation();
        Point castle2Loc = gameEngine.getPlayer2CastleLocation();

        for (int i = 0; i < gameEngine.getMapSizeX(); i++){
            for (int j = 0; j < gameEngine.getMapSizeY(); j++){
                if (map[i][j] instanceof Lake || map[i][j] instanceof Mountain){
                    assertTrue(castle1Loc.distance((int)i, (int)j) >= 2 &&
                            castle2Loc.distance((int)i, (int)j) >= 2);
                }
            }
        }
    }

    @Test
    public void ChangePlayer() {
        PlayerDetails currentPlayer = gameEngine.getCurrentPlayer();
        gameEngine.changeCurrentPlayer();
        PlayerDetails nextPlayer = gameEngine.getCurrentPlayer();
        assertNotEquals(currentPlayer, nextPlayer);
        gameEngine.changeCurrentPlayer();

        assertEquals(currentPlayer, gameEngine.getCurrentPlayer());
    }

    @Test
    public void addUnits() {
        PlayerDetails player = gameEngine.getCurrentPlayer();
        Point castleLoc = player.getCastleLocation();

        player.addUnit(new FighterUnit((int)castleLoc.getX(), (int)castleLoc.getY(), player));
        player.addUnit(new FighterUnit((int)castleLoc.getX(), (int)castleLoc.getY(), player));

        int units = player.getNumberOfUnitsAt((int)castleLoc.getX(), (int)castleLoc.getY());

        assertEquals(units, 2);
    }

    @Test
    public void addTower() {
        PlayerDetails player = gameEngine.getCurrentPlayer();
        Point castleLoc = player.getCastleLocation();
        int x = (int) castleLoc.getX();
        int y = (int) castleLoc.getY();

        player.addTower(new Tower(x, y, player, 0, 0, 0, 0));
        player.addTower(new Tower(x, y, player, 0, 0, 0, 0));

        int towers = player.getNumberOfTowersAt((int)castleLoc.getX(), (int)castleLoc.getY());

        assertEquals(towers, 2);
    }

    @Test
    public void gainMoney(){
        PlayerDetails player = gameEngine.getCurrentPlayer();
        assertEquals(2000, player.getMoney());

        Point castleLoc = player.getCastleLocation();
        int x = (int) castleLoc.getX();
        int y = (int) castleLoc.getY();

        player.addUnit(new FighterUnit(x, y, player, gameEngine));
        player.addUnit(new FighterUnit(x, y, player, gameEngine));
        int currMoney = player.getMoney();

        gameEngine.changeCurrentPlayer();
        gameEngine.changeCurrentPlayer();

        assertTrue(currMoney < player.getMoney());
    }

    @Test
    public void addBarrack() {
        PlayerDetails player = gameEngine.getCurrentPlayer();
        Point castleLoc = player.getCastleLocation();
        int x = (int) castleLoc.getX() + 1;
        int y = (int) castleLoc.getY() + 1;
        player.addBarrack(new Barrack(x, y, player));

        assertEquals(player.getBarracks().size(), 3);
    }

    @Test
    public void getRandomBarrackLocation() {
        PlayerDetails player = gameEngine.getCurrentPlayer();

        Point point = player.getRandomBarrackLocation();
        MapObject[][] map = GameEngine.map;

        assertTrue(map[point.x][point.y] instanceof Barrack);
    }

    @Test
    public void numberOfUnitsTrained() {
        PlayerDetails player = gameEngine.getCurrentPlayer();
        Point castleLoc = player.getCastleLocation();

        player.addUnit(new FighterUnit((int)castleLoc.getX(), (int)castleLoc.getY(), player));
        player.addUnit(new FighterUnit((int)castleLoc.getX(), (int)castleLoc.getY(), player));

        assertEquals(player.getNumberOfUnitsTrained(), 2);
    }

    @Test
    public void incrementKilledUnits() {
        PlayerDetails player = gameEngine.getCurrentPlayer();
        player.incrementKilledUnits();

        assertEquals(player.getKilledUnits(), 1);
    }
}